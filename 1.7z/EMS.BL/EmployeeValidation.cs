﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;
using EMS.DAL;
using System.Data;

namespace EMS.BL
{
    public class EmployeeValidation
    {
        EMSOperations operationObj = new EMSOperations();

        public bool ValidateEmployee(EmployeeDetails empDetails)
        {
            bool validEmp = true;
            StringBuilder sb = new StringBuilder();
            if (empDetails.EmpFName.ToString().Length == 0)
            {
                validEmp = false;
                sb.Append(Environment.NewLine + "Guest ID is required.");
            }
            //if (empDetails.EmpFName.Length == 0)
            //{
            //    validGuest = false;
            //    sb.Append(Environment.NewLine + "Guest Name is required.");
            //}
            //if (empDetails.ContactNo.ToString().Length == 0)
            //{
            //    validGuest = false;
            //    sb.Append(Environment.NewLine + "Guest Contact No is required.");
            //}
            //if (!(Regex.IsMatch(empDetails.GuestID.ToString(), @"^[0-9]+$")))
            //{
            //    validGuest = false;
            //    sb.Append(Environment.NewLine + "Guest ID should contain only numbers.");
            //}
            //if (!(Regex.IsMatch(empDetails.GuestName, @"^[a-zA-Z ]+$")))
            //{
            //    validGuest = false;
            //    sb.Append(Environment.NewLine + "Employee Name should contain only characters.");
            //}
            //if (!(Regex.IsMatch(empDetails.ContactNo.ToString(), @"^[0-9]+$")))
            //{
            //    validGuest = false;
            //    sb.Append(Environment.NewLine + "Contact number should contain only numbers.");
            //}
            //if (empDetails.ContactNo.ToString().Length != 10)
            //{
            //    validGuest = false;
            //    sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
            //}
            if (validEmp == false)
                throw new CustomException(sb.ToString());
            return validEmp;
        }

        public bool AddEmployeeRecord(EmployeeDetails emp)
        {
            bool empAdded = false;
            if (ValidateEmployee(emp))
                empAdded = operationObj.AddEmployeeRecord(emp);
            return empAdded;
        }

        public DataTable DisplayAllEmployeeDetails()
        {

            DataTable empTable = operationObj.DisplayAllEmployeeDetails();
            return empTable;
        }

        public DataTable SearchEmpByID(int empID)
        {
     
            DataTable empTable = operationObj.SearchEmpByID(empID);
            return empTable;

        }



    }
}
