﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using EMS.Entity;
using EMS.Exception;

namespace EMS.DAL
{
    public class EMSOperations
    {
        SqlConnection connection;
        SqlDataReader reader;
        SqlCommand cmd = new SqlCommand();
        public EMSOperations()
        {

            string connectionString = ConfigurationManager.ConnectionStrings["EMS"].ConnectionString;
            connection = new SqlConnection(connectionString);

        }


        ////Employee info
        //public DataTable MyInfo(int empID)
        //{
        //    DataTable table = new DataTable();
        //    try
        //    {
        //        cmd = new SqlCommand("[MySchemaEMS].usp_EmployeeInfo", connection);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@EmpID", empID);
        //        connection.Open();
        //        reader = cmd.ExecuteReader();
        //        table.Load(reader);
        //    }
        //    catch (CustomException)
        //    {
        //        throw new CustomException("Employee ID does Not Exist");
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {

        //        throw ex;
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return table;
        //}

        ////update employee details
        //public bool UpdateEmployeeDetails(EmployeeDetails emp)
        //{
        //    bool empUpdated = false;
        //    try
        //    {
        //        cmd = new SqlCommand("[MySchemaEMS].usp_UpdateEmployeeInfo", connection);
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@EmpID", emp.EmpID);
        //        cmd.Parameters.AddWithValue("@EmpFName", emp.EmpFName);
        //        cmd.Parameters.AddWithValue("@EmpLName", emp.EmpLName);
        //        cmd.Parameters.AddWithValue("@EmpGender", emp.EmpGender);
        //        cmd.Parameters.AddWithValue("@EmpAge", emp.EmpAge);
        //        cmd.Parameters.AddWithValue("@EmpSkills", emp.EmpSkills);
        //        cmd.Parameters.AddWithValue("@EmpAddress", emp.EmpAddress);
        //        cmd.Parameters.AddWithValue("@EmpDOB", emp.EmpDOB);
        //        cmd.Parameters.AddWithValue("@EmpContactNo", emp.EmpContactNo);
        //        cmd.Parameters.AddWithValue("@EmpEmailId", emp.EmpEmailId);
        //        connection.Open();
        //        int result = cmd.ExecuteNonQuery();
        //        if (result > 0)
        //        {
        //            empUpdated = true;
        //        }
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (CustomException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {

        //        throw ex;
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return empUpdated;
        //}

        ////upcoming birthdays
        //public DataTable UpcomingBirthdateDetails()
        //{

        //    DataTable table = new DataTable();
        //    try
        //    {
        //        cmd = new SqlCommand("[MySchemaEMS].usp_EmployeeBirthday", connection);
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        connection.Open();
        //        reader = cmd.ExecuteReader();
        //        table.Load(reader);
        //    }
        //    catch (CustomException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {

        //        throw ex;
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return table;
        // }

        // ADMIN AND hr
        public bool AddEmployeeRecord(EmployeeDetails emp)
        {
            try
            {
                bool empAdded = false;
                cmd = new SqlCommand("[MySchemaEMS].usp_AddEmployeeRecord", connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@DeptID", emp.DeptID);
                cmd.Parameters.AddWithValue("@EmpFName", emp.EmpFName);
                cmd.Parameters.AddWithValue("@EmpLName", emp.EmpLName);
                cmd.Parameters.AddWithValue("@EmpGender", emp.EmpGender);
                cmd.Parameters.AddWithValue("@EmpAge", emp.EmpAge);
                cmd.Parameters.AddWithValue("@EmpSkills", emp.EmpSkills);
                cmd.Parameters.AddWithValue("@EmpDesignation", emp.EmpDesignation);
                cmd.Parameters.AddWithValue("@EmpSalary", emp.EmpSalary);
                cmd.Parameters.AddWithValue("@EmpAddress", emp.EmpAddress);
                cmd.Parameters.AddWithValue("@EmpDOB", emp.EmpDOB);
                cmd.Parameters.AddWithValue("@EmpDOJ", emp.EmpDOJ);
                cmd.Parameters.AddWithValue("@EmpContactNo", emp.EmpContactNo);
                cmd.Parameters.AddWithValue("@EmpEmailId", emp.EmpEmailId);

                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                    empAdded = true;
                return empAdded;
            }
            catch (CustomException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        //      //admin view employee details
        public DataTable DisplayAllEmployeeDetails()
        {

            DataTable table = new DataTable();
            try
            {
                cmd = new SqlCommand("[MySchemaEMS].usp_DisplayAllEmployeeRecord", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                connection.Open();
                reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (CustomException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return table;
        }

        //      public DataTable DisplayLoginDetails()
        //      {

        //          DataTable table = new DataTable();
        //          try
        //          {
        //              cmd = new SqlCommand(" [MySchemaEMS].usp_DisplayAllLoginDetails", connection);
        //              cmd.CommandType = CommandType.StoredProcedure;
        //              connection.Open();
        //              reader = cmd.ExecuteReader();
        //              table.Load(reader);
        //          }
        //          catch (CustomException ex)
        //          {
        //              throw ex;
        //          }
        //          catch (SqlException ex)
        //          {
        //              throw ex;
        //          }
        //          catch (SystemException ex)
        //          {

        //              throw ex;
        //          }
        //          finally
        //          {
        //              connection.Close();
        //          }
        //          return table;
        //      }


        //      public DataTable DisplayEmpByDept(string deptName)
        //      {
        //          DataTable table = new DataTable();
        //          try
        //          {
        //              cmd = new SqlCommand("[MySchemaEMS].usp_RetrieveAllEmployeeDetails", connection);
        //              cmd.CommandType = CommandType.StoredProcedure;
        //              cmd.Parameters.AddWithValue("@DeptName", deptName);
        //              connection.Open();
        //              reader = cmd.ExecuteReader();
        //              table.Load(reader);
        //          }
        //          catch (CustomException)
        //          {
        //              throw new CustomException("Employee ID does Not Exist");
        //          }
        //          catch (SqlException ex)
        //          {
        //              throw ex;
        //          }
        //          catch (SystemException ex)
        //          {

        //              throw ex;
        //          }
        //          finally
        //          {
        //              connection.Close();
        //          }
        //          return table;
        //      }

        //      public DataTable MyInfo(int empID)
        //      {
        //          DataTable table = new DataTable();
        //          try
        //          {
        //              cmd = new SqlCommand("[MySchemaEMS].usp_EmployeeInfo", connection);
        //              cmd.CommandType = CommandType.StoredProcedure;
        //              cmd.Parameters.AddWithValue("@EmpID", id);
        //              connection.Open();
        //              reader = cmd.ExecuteReader();
        //              table.Load(reader);
        //          }
        //          catch (CustomException)
        //          {
        //              throw new CustomException("Employee ID does Not Exist");
        //          }
        //          catch (SqlException ex)
        //          {
        //              throw ex;
        //          }
        //          catch (SystemException ex)
        //          {

        //              throw ex;
        //          }
        //          finally
        //          {
        //              connection.Close();
        //          }
        //          return table;
        //      }

        public DataTable SearchEmpByID(int empID)
        {
            DataTable table = new DataTable();
            try
            {
                cmd = new SqlCommand("[MySchemaEMS].usp_EmployeeInfo", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpID", empID);
                connection.Open();
                reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (CustomException)
            {
                throw new CustomException("Employee ID does Not Exist");
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return table;
        }

        //      public bool DeleteEmployeeDetails(int empID)
        //      {
        //          bool empDeleted = false;
        //          try
        //          {
        //              cmd = new SqlCommand("[MySchemaEMS].usp_DeleteEmployeeRecord", connection);
        //              cmd.CommandType = CommandType.StoredProcedure;
        //              cmd.Parameters.AddWithValue("@EmpID", empID);
        //              connection.Open();
        //              int result = cmd.ExecuteNonQuery();
        //              if (result > 0)
        //              {
        //                  empDeleted = true;
        //              }
        //          }
        //          catch (CustomException ex)
        //          {

        //              throw ex;
        //          }
        //          catch (SqlException ex)
        //          {
        //              throw ex;
        //          }
        //          catch (SystemException ex)
        //          {
        //              throw ex;
        //          }

        //          finally
        //          {
        //              connection.Close();
        //          }
        //          return empDeleted;

        //      }


        ////--------------------------------------------------------------------------------------------------
        //      public DataTable RetrieveEmployeeDetails(int EmpID)
        //      {
        //          SqlCommand cmdGetEmp = new SqlCommand("RetrieveEmployeeDetails", connection);
        //          cmdGetEmp.CommandType = CommandType.StoredProcedure;
        //          cmdGetEmp.Parameters.AddWithValue("@EmpID", EmpID);
        //          if (connection.State == ConnectionState.Closed)
        //              connection.Open();
        //          reader = cmdGetEmp.ExecuteReader();
        //          DataTable EmpTable = new DataTable();
        //          EmpTable.Load(reader);
        //          return EmpTable;
        //      }

        //      public bool DeleteEmployeeDetails(int EmpID) 
        //      {
        //          bool EmpDeleted = false;
        //          try
        //          {
        //              SqlCommand cmdDelEmp = new SqlCommand("DeleteEmployeeDetails", connection);
        //              cmdDelEmp.CommandType = CommandType.StoredProcedure;
        //              cmdDelEmp.Parameters.AddWithValue("@EmpID", EmpID);
        //              if (connection.State == ConnectionState.Closed)
        //                  connection.Open();
        //              int Result = cmdDelEmp.ExecuteNonQuery();
        //              if (Result > 0)
        //                  EmpDeleted = true;

        //          }
        //          catch (CustomException) { throw; }
        //          catch (SqlException) { throw; }
        //          catch (SystemException) { throw; }
        //          finally { connection.Close();    }
        //          return EmpDeleted;
        //      }

        //      public bool UpdateEmployee(EmployeeDetails emp) 
        //      {
        //          bool EmpUpdated = false;
        //          try 
        //          {
        //              SqlCommand cmdUpdateEmp = new SqlCommand("UpdateEmployee", connection);
        //              cmdUpdateEmp.CommandType = CommandType.StoredProcedure;
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpID",emp.EmpID);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpFName", emp.EmpFName);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpLName", emp.EmpLName);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpGender", emp.EmpGender);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpAge", emp.EmpAge);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpSkills", emp.EmpSkills);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpDesignation", emp.EmpDesignation);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpSalary", emp.EmpSalary);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpAddress", emp.EmpAddress);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpDOB", emp.EmpDOB);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpDOJ", emp.EmpDOJ);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpContactNo", emp.EmpContactNo);
        //              cmdUpdateEmp.Parameters.AddWithValue("@EmpEmailId", emp.EmpEmailId);

        //              if (connection.State == ConnectionState.Closed)
        //                  connection.Open();
        //              int result = cmdUpdateEmp.ExecuteNonQuery();
        //              if (result > 0)
        //                  EmpUpdated = true;

        //          }
        //          catch (CustomException) { throw; }
        //          catch (SqlException) { throw; }
        //          catch (SystemException) { throw; }
        //          finally { connection.Close(); }
        //          return EmpUpdated;
        //      }

    }
}
