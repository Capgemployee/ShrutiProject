﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    public class EmployeeDetails
    {
        #region Property
        public int EmpID { get; set; }

        public int DeptID { get; set; }

        public String EmpFName { get; set; }

        public String EmpLName { get; set; }

        public char EmpGender { get; set; }

        public int EmpAge { get; set; }

        public String EmpDesignation { get; set; }

        public string EmpSkills { get; set; }

        public int EmpSalary { get; set; }

        public string EmpAddress { get; set; }

        public DateTime EmpDOB { get; set; }

        public DateTime EmpDOJ { get; set; }

        public string EmpContactNo { get; set; }

        public string EmpEmailId { get; set; }
        #endregion
    }
}
