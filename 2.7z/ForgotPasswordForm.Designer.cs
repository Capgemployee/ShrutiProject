﻿namespace Employee_Management_System
{
    partial class ForgotPasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtAnswer1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnSubmitAnswer = new System.Windows.Forms.Button();
            this.lblAns1 = new System.Windows.Forms.Label();
            this.lblSecurityQuestion1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPwdChng = new System.Windows.Forms.Label();
            this.cmbSecurityQuestion1 = new System.Windows.Forms.ComboBox();
            this.cmbSecurityQuestion2 = new System.Windows.Forms.ComboBox();
            this.txtAnswer2 = new System.Windows.Forms.TextBox();
            this.lblAns2 = new System.Windows.Forms.Label();
            this.lblSecurityQuestion2 = new System.Windows.Forms.Label();
            this.cmbSecurityQuestion3 = new System.Windows.Forms.ComboBox();
            this.txtAnswer3 = new System.Windows.Forms.TextBox();
            this.lblAns3 = new System.Windows.Forms.Label();
            this.lblSecurityQuestion3 = new System.Windows.Forms.Label();
            this.cmbSecurityQuestion4 = new System.Windows.Forms.ComboBox();
            this.txtAnswer4 = new System.Windows.Forms.TextBox();
            this.lblAns4 = new System.Windows.Forms.Label();
            this.lblSecurityQuestion4 = new System.Windows.Forms.Label();
            this.cmbSecurityQuestion5 = new System.Windows.Forms.ComboBox();
            this.txtAnswer5 = new System.Windows.Forms.TextBox();
            this.lblAns5 = new System.Windows.Forms.Label();
            this.lblSecurityQuestion5 = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.btnChangePassword = new System.Windows.Forms.Button();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.lblNewPassword = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.lblPasswordChange = new System.Windows.Forms.Label();
            this.lblDisplayUserID = new System.Windows.Forms.Label();
            this.lblDisplayUserName = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtAnswer1
            // 
            this.txtAnswer1.ForeColor = System.Drawing.Color.Black;
            this.txtAnswer1.Location = new System.Drawing.Point(160, 167);
            this.txtAnswer1.Name = "txtAnswer1";
            this.txtAnswer1.Size = new System.Drawing.Size(429, 20);
            this.txtAnswer1.TabIndex = 4;
            this.txtAnswer1.TextChanged += new System.EventHandler(this.txtAnswer1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.ForeColor = System.Drawing.Color.Black;
            this.textBox2.Location = new System.Drawing.Point(160, 96);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(429, 20);
            this.textBox2.TabIndex = 2;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.ForeColor = System.Drawing.Color.Black;
            this.textBox1.Location = new System.Drawing.Point(160, 68);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(429, 20);
            this.textBox1.TabIndex = 1;
            // 
            // btnSubmitAnswer
            // 
            this.btnSubmitAnswer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(56)))));
            this.btnSubmitAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitAnswer.ForeColor = System.Drawing.Color.White;
            this.btnSubmitAnswer.Location = new System.Drawing.Point(34, 504);
            this.btnSubmitAnswer.Name = "btnSubmitAnswer";
            this.btnSubmitAnswer.Size = new System.Drawing.Size(555, 40);
            this.btnSubmitAnswer.TabIndex = 13;
            this.btnSubmitAnswer.Text = "Submit Answers";
            this.btnSubmitAnswer.UseVisualStyleBackColor = false;
            this.btnSubmitAnswer.Click += new System.EventHandler(this.btnChangePassword_Click);
            // 
            // lblAns1
            // 
            this.lblAns1.AutoSize = true;
            this.lblAns1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAns1.ForeColor = System.Drawing.Color.White;
            this.lblAns1.Location = new System.Drawing.Point(91, 171);
            this.lblAns1.Name = "lblAns1";
            this.lblAns1.Size = new System.Drawing.Size(65, 16);
            this.lblAns1.TabIndex = 15;
            this.lblAns1.Text = " Answer 1";
            // 
            // lblSecurityQuestion1
            // 
            this.lblSecurityQuestion1.AutoSize = true;
            this.lblSecurityQuestion1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecurityQuestion1.ForeColor = System.Drawing.Color.White;
            this.lblSecurityQuestion1.Location = new System.Drawing.Point(31, 144);
            this.lblSecurityQuestion1.Name = "lblSecurityQuestion1";
            this.lblSecurityQuestion1.Size = new System.Drawing.Size(125, 16);
            this.lblSecurityQuestion1.TabIndex = 14;
            this.lblSecurityQuestion1.Text = " Security Question 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(47, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 16);
            this.label3.TabIndex = 13;
            this.label3.Text = "Email Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(93, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 16);
            this.label2.TabIndex = 12;
            this.label2.Text = "UserID";
            // 
            // lblPwdChng
            // 
            this.lblPwdChng.AutoSize = true;
            this.lblPwdChng.Font = new System.Drawing.Font("Lucida Sans", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPwdChng.ForeColor = System.Drawing.Color.White;
            this.lblPwdChng.Location = new System.Drawing.Point(137, 9);
            this.lblPwdChng.Name = "lblPwdChng";
            this.lblPwdChng.Size = new System.Drawing.Size(367, 37);
            this.lblPwdChng.TabIndex = 11;
            this.lblPwdChng.Text = "Reset Your Password";
            this.lblPwdChng.Click += new System.EventHandler(this.lblPwdChng_Click);
            // 
            // cmbSecurityQuestion1
            // 
            this.cmbSecurityQuestion1.ForeColor = System.Drawing.Color.Black;
            this.cmbSecurityQuestion1.FormattingEnabled = true;
            this.cmbSecurityQuestion1.Items.AddRange(new object[] {
            "What is the first and last name of your first boyfriend or girlfriend?",
            "Which phone number do you remember most from your childhood?",
            "What was your favorite place to visit as a child?",
            "Who is your favorite actor, musician, or artist?",
            "What is the name of your favorite pet?",
            "In what city were you born?",
            "What high school did you attend?",
            "What is the name of your first school?",
            "What is your favorite movie?",
            "What is your mother\'s maiden name?",
            "What street did you grow up on?",
            "What was the make of your first car?",
            "When is your anniversary?",
            "What is your favorite color?",
            "•What is your father\'s middle name?",
            "•What is the name of your first grade teacher?",
            "•What was your high school mascot?",
            "•Which is your favorite web browser?"});
            this.cmbSecurityQuestion1.Location = new System.Drawing.Point(160, 139);
            this.cmbSecurityQuestion1.Name = "cmbSecurityQuestion1";
            this.cmbSecurityQuestion1.Size = new System.Drawing.Size(429, 21);
            this.cmbSecurityQuestion1.TabIndex = 3;
            this.cmbSecurityQuestion1.Text = "--- Select Security Question ---";
            // 
            // cmbSecurityQuestion2
            // 
            this.cmbSecurityQuestion2.ForeColor = System.Drawing.Color.Black;
            this.cmbSecurityQuestion2.FormattingEnabled = true;
            this.cmbSecurityQuestion2.Items.AddRange(new object[] {
            "•What is the first and last name of your first boyfriend or girlfriend?",
            "•Which phone number do you remember most from your childhood?",
            "•What was your favorite place to visit as a child?",
            "•Who is your favorite actor, musician, or artist?",
            "•What is the name of your favorite pet?",
            "•In what city were you born?",
            "•What high school did you attend?",
            "•What is the name of your first school?",
            "•What is your favorite movie?",
            "•What is your mother\'s maiden name?",
            "•What street did you grow up on?",
            "•What was the make of your first car?",
            "•When is your anniversary?",
            "•What is your favorite color?",
            "•What is your father\'s middle name?",
            "•What is the name of your first grade teacher?",
            "•What was your high school mascot?",
            "•Which is your favorite web browser?"});
            this.cmbSecurityQuestion2.Location = new System.Drawing.Point(160, 209);
            this.cmbSecurityQuestion2.Name = "cmbSecurityQuestion2";
            this.cmbSecurityQuestion2.Size = new System.Drawing.Size(429, 21);
            this.cmbSecurityQuestion2.TabIndex = 5;
            this.cmbSecurityQuestion2.Text = "--- Select Security Question ---";
            // 
            // txtAnswer2
            // 
            this.txtAnswer2.ForeColor = System.Drawing.Color.Black;
            this.txtAnswer2.Location = new System.Drawing.Point(160, 236);
            this.txtAnswer2.Name = "txtAnswer2";
            this.txtAnswer2.Size = new System.Drawing.Size(429, 20);
            this.txtAnswer2.TabIndex = 6;
            this.txtAnswer2.TextChanged += new System.EventHandler(this.txtAnswer2_TextChanged);
            // 
            // lblAns2
            // 
            this.lblAns2.AutoSize = true;
            this.lblAns2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAns2.ForeColor = System.Drawing.Color.White;
            this.lblAns2.Location = new System.Drawing.Point(88, 241);
            this.lblAns2.Name = "lblAns2";
            this.lblAns2.Size = new System.Drawing.Size(65, 16);
            this.lblAns2.TabIndex = 25;
            this.lblAns2.Text = " Answer 2";
            // 
            // lblSecurityQuestion2
            // 
            this.lblSecurityQuestion2.AutoSize = true;
            this.lblSecurityQuestion2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecurityQuestion2.ForeColor = System.Drawing.Color.White;
            this.lblSecurityQuestion2.Location = new System.Drawing.Point(28, 214);
            this.lblSecurityQuestion2.Name = "lblSecurityQuestion2";
            this.lblSecurityQuestion2.Size = new System.Drawing.Size(125, 16);
            this.lblSecurityQuestion2.TabIndex = 24;
            this.lblSecurityQuestion2.Text = " Security Question 2";
            // 
            // cmbSecurityQuestion3
            // 
            this.cmbSecurityQuestion3.ForeColor = System.Drawing.Color.Black;
            this.cmbSecurityQuestion3.FormattingEnabled = true;
            this.cmbSecurityQuestion3.Items.AddRange(new object[] {
            "•What is the first and last name of your first boyfriend or girlfriend?",
            "•Which phone number do you remember most from your childhood?",
            "•What was your favorite place to visit as a child?",
            "•Who is your favorite actor, musician, or artist?",
            "•What is the name of your favorite pet?",
            "•In what city were you born?",
            "•What high school did you attend?",
            "•What is the name of your first school?",
            "•What is your favorite movie?",
            "•What is your mother\'s maiden name?",
            "•What street did you grow up on?",
            "•What was the make of your first car?",
            "•When is your anniversary?",
            "•What is your favorite color?",
            "•What is your father\'s middle name?",
            "•What is the name of your first grade teacher?",
            "•What was your high school mascot?",
            "•Which is your favorite web browser?"});
            this.cmbSecurityQuestion3.Location = new System.Drawing.Point(160, 279);
            this.cmbSecurityQuestion3.Name = "cmbSecurityQuestion3";
            this.cmbSecurityQuestion3.Size = new System.Drawing.Size(429, 21);
            this.cmbSecurityQuestion3.TabIndex = 7;
            this.cmbSecurityQuestion3.Text = "--- Select Security Question ---";
            // 
            // txtAnswer3
            // 
            this.txtAnswer3.ForeColor = System.Drawing.Color.Black;
            this.txtAnswer3.Location = new System.Drawing.Point(160, 309);
            this.txtAnswer3.Name = "txtAnswer3";
            this.txtAnswer3.Size = new System.Drawing.Size(429, 20);
            this.txtAnswer3.TabIndex = 8;
            this.txtAnswer3.TextChanged += new System.EventHandler(this.txtAnswer3_TextChanged);
            // 
            // lblAns3
            // 
            this.lblAns3.AutoSize = true;
            this.lblAns3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAns3.ForeColor = System.Drawing.Color.White;
            this.lblAns3.Location = new System.Drawing.Point(91, 312);
            this.lblAns3.Name = "lblAns3";
            this.lblAns3.Size = new System.Drawing.Size(65, 16);
            this.lblAns3.TabIndex = 29;
            this.lblAns3.Text = " Answer 3";
            // 
            // lblSecurityQuestion3
            // 
            this.lblSecurityQuestion3.AutoSize = true;
            this.lblSecurityQuestion3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecurityQuestion3.ForeColor = System.Drawing.Color.White;
            this.lblSecurityQuestion3.Location = new System.Drawing.Point(31, 285);
            this.lblSecurityQuestion3.Name = "lblSecurityQuestion3";
            this.lblSecurityQuestion3.Size = new System.Drawing.Size(125, 16);
            this.lblSecurityQuestion3.TabIndex = 28;
            this.lblSecurityQuestion3.Text = " Security Question 3";
            // 
            // cmbSecurityQuestion4
            // 
            this.cmbSecurityQuestion4.ForeColor = System.Drawing.Color.Black;
            this.cmbSecurityQuestion4.FormattingEnabled = true;
            this.cmbSecurityQuestion4.Items.AddRange(new object[] {
            "•What is the first and last name of your first boyfriend or girlfriend?",
            "•Which phone number do you remember most from your childhood?",
            "•What was your favorite place to visit as a child?",
            "•Who is your favorite actor, musician, or artist?",
            "•What is the name of your favorite pet?",
            "•In what city were you born?",
            "•What high school did you attend?",
            "•What is the name of your first school?",
            "•What is your favorite movie?",
            "•What is your mother\'s maiden name?",
            "•What street did you grow up on?",
            "•What was the make of your first car?",
            "•When is your anniversary?",
            "•What is your favorite color?",
            "•What is your father\'s middle name?",
            "•What is the name of your first grade teacher?",
            "•What was your high school mascot?",
            "•Which is your favorite web browser?"});
            this.cmbSecurityQuestion4.Location = new System.Drawing.Point(160, 355);
            this.cmbSecurityQuestion4.Name = "cmbSecurityQuestion4";
            this.cmbSecurityQuestion4.Size = new System.Drawing.Size(429, 21);
            this.cmbSecurityQuestion4.TabIndex = 9;
            this.cmbSecurityQuestion4.Text = "--- Select Security Question ---";
            // 
            // txtAnswer4
            // 
            this.txtAnswer4.ForeColor = System.Drawing.Color.Black;
            this.txtAnswer4.Location = new System.Drawing.Point(160, 382);
            this.txtAnswer4.Name = "txtAnswer4";
            this.txtAnswer4.Size = new System.Drawing.Size(429, 20);
            this.txtAnswer4.TabIndex = 10;
            this.txtAnswer4.TextChanged += new System.EventHandler(this.txtAnswer4_TextChanged);
            // 
            // lblAns4
            // 
            this.lblAns4.AutoSize = true;
            this.lblAns4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAns4.ForeColor = System.Drawing.Color.White;
            this.lblAns4.Location = new System.Drawing.Point(88, 386);
            this.lblAns4.Name = "lblAns4";
            this.lblAns4.Size = new System.Drawing.Size(65, 16);
            this.lblAns4.TabIndex = 33;
            this.lblAns4.Text = " Answer 4";
            // 
            // lblSecurityQuestion4
            // 
            this.lblSecurityQuestion4.AutoSize = true;
            this.lblSecurityQuestion4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecurityQuestion4.ForeColor = System.Drawing.Color.White;
            this.lblSecurityQuestion4.Location = new System.Drawing.Point(28, 359);
            this.lblSecurityQuestion4.Name = "lblSecurityQuestion4";
            this.lblSecurityQuestion4.Size = new System.Drawing.Size(125, 16);
            this.lblSecurityQuestion4.TabIndex = 32;
            this.lblSecurityQuestion4.Text = " Security Question 4";
            // 
            // cmbSecurityQuestion5
            // 
            this.cmbSecurityQuestion5.ForeColor = System.Drawing.Color.Black;
            this.cmbSecurityQuestion5.FormattingEnabled = true;
            this.cmbSecurityQuestion5.Items.AddRange(new object[] {
            "•What is the first and last name of your first boyfriend or girlfriend?",
            "•Which phone number do you remember most from your childhood?",
            "•What was your favorite place to visit as a child?",
            "•Who is your favorite actor, musician, or artist?",
            "•What is the name of your favorite pet?",
            "•In what city were you born?",
            "•What high school did you attend?",
            "•What is the name of your first school?",
            "•What is your favorite movie?",
            "•What is your mother\'s maiden name?",
            "•What street did you grow up on?",
            "•What was the make of your first car?",
            "•When is your anniversary?",
            "•What is your favorite color?",
            "•What is your father\'s middle name?",
            "•What is the name of your first grade teacher?",
            "•What was your high school mascot?",
            "•Which is your favorite web browser?"});
            this.cmbSecurityQuestion5.Location = new System.Drawing.Point(160, 431);
            this.cmbSecurityQuestion5.Name = "cmbSecurityQuestion5";
            this.cmbSecurityQuestion5.Size = new System.Drawing.Size(429, 21);
            this.cmbSecurityQuestion5.TabIndex = 11;
            this.cmbSecurityQuestion5.Text = "--- Select Security Question ---";
            // 
            // txtAnswer5
            // 
            this.txtAnswer5.ForeColor = System.Drawing.Color.Black;
            this.txtAnswer5.Location = new System.Drawing.Point(160, 458);
            this.txtAnswer5.Name = "txtAnswer5";
            this.txtAnswer5.Size = new System.Drawing.Size(429, 20);
            this.txtAnswer5.TabIndex = 12;
            this.txtAnswer5.TextChanged += new System.EventHandler(this.txtAnswer5_TextChanged);
            // 
            // lblAns5
            // 
            this.lblAns5.AutoSize = true;
            this.lblAns5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAns5.ForeColor = System.Drawing.Color.White;
            this.lblAns5.Location = new System.Drawing.Point(91, 463);
            this.lblAns5.Name = "lblAns5";
            this.lblAns5.Size = new System.Drawing.Size(65, 16);
            this.lblAns5.TabIndex = 37;
            this.lblAns5.Text = " Answer 5";
            // 
            // lblSecurityQuestion5
            // 
            this.lblSecurityQuestion5.AutoSize = true;
            this.lblSecurityQuestion5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecurityQuestion5.ForeColor = System.Drawing.Color.White;
            this.lblSecurityQuestion5.Location = new System.Drawing.Point(31, 436);
            this.lblSecurityQuestion5.Name = "lblSecurityQuestion5";
            this.lblSecurityQuestion5.Size = new System.Drawing.Size(125, 16);
            this.lblSecurityQuestion5.TabIndex = 36;
            this.lblSecurityQuestion5.Text = " Security Question 5";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.ForeColor = System.Drawing.Color.Black;
            this.txtConfirmPassword.Location = new System.Drawing.Point(172, 163);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Size = new System.Drawing.Size(185, 21);
            this.txtConfirmPassword.TabIndex = 15;
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.ForeColor = System.Drawing.Color.Black;
            this.txtNewPassword.Location = new System.Drawing.Point(172, 136);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Size = new System.Drawing.Size(185, 21);
            this.txtNewPassword.TabIndex = 14;
            // 
            // btnChangePassword
            // 
            this.btnChangePassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(56)))));
            this.btnChangePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangePassword.ForeColor = System.Drawing.Color.White;
            this.btnChangePassword.Location = new System.Drawing.Point(37, 196);
            this.btnChangePassword.Name = "btnChangePassword";
            this.btnChangePassword.Size = new System.Drawing.Size(192, 25);
            this.btnChangePassword.TabIndex = 16;
            this.btnChangePassword.Text = "CHANGE PASSWORD";
            this.btnChangePassword.UseVisualStyleBackColor = false;
            this.btnChangePassword.Click += new System.EventHandler(this.btnChangePassword_Click_1);
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmPassword.ForeColor = System.Drawing.Color.White;
            this.lblConfirmPassword.Location = new System.Drawing.Point(42, 167);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(116, 16);
            this.lblConfirmPassword.TabIndex = 44;
            this.lblConfirmPassword.Text = "Confirm Password";
            // 
            // lblNewPassword
            // 
            this.lblNewPassword.AutoSize = true;
            this.lblNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewPassword.ForeColor = System.Drawing.Color.White;
            this.lblNewPassword.Location = new System.Drawing.Point(60, 140);
            this.lblNewPassword.Name = "lblNewPassword";
            this.lblNewPassword.Size = new System.Drawing.Size(98, 16);
            this.lblNewPassword.TabIndex = 43;
            this.lblNewPassword.Text = "New Password\r\n";
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserID.ForeColor = System.Drawing.Color.White;
            this.lblUserID.Location = new System.Drawing.Point(105, 113);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(53, 16);
            this.lblUserID.TabIndex = 42;
            this.lblUserID.Text = "User ID";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.White;
            this.lblUserName.Location = new System.Drawing.Point(84, 85);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(74, 16);
            this.lblUserName.TabIndex = 41;
            this.lblUserName.Text = "UserName";
            // 
            // lblPasswordChange
            // 
            this.lblPasswordChange.AutoSize = true;
            this.lblPasswordChange.Font = new System.Drawing.Font("Lucida Sans", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswordChange.ForeColor = System.Drawing.Color.White;
            this.lblPasswordChange.Location = new System.Drawing.Point(69, 33);
            this.lblPasswordChange.Name = "lblPasswordChange";
            this.lblPasswordChange.Size = new System.Drawing.Size(262, 32);
            this.lblPasswordChange.TabIndex = 40;
            this.lblPasswordChange.Text = "Password Change";
            // 
            // lblDisplayUserID
            // 
            this.lblDisplayUserID.AutoSize = true;
            this.lblDisplayUserID.Location = new System.Drawing.Point(172, 113);
            this.lblDisplayUserID.Name = "lblDisplayUserID";
            this.lblDisplayUserID.Size = new System.Drawing.Size(84, 15);
            this.lblDisplayUserID.TabIndex = 51;
            this.lblDisplayUserID.Text = "[User ID Here]";
            // 
            // lblDisplayUserName
            // 
            this.lblDisplayUserName.AutoSize = true;
            this.lblDisplayUserName.Location = new System.Drawing.Point(172, 85);
            this.lblDisplayUserName.Name = "lblDisplayUserName";
            this.lblDisplayUserName.Size = new System.Drawing.Size(106, 15);
            this.lblDisplayUserName.TabIndex = 52;
            this.lblDisplayUserName.Text = "[User Name Here]";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnExit);
            this.groupBox1.Controls.Add(this.lblPasswordChange);
            this.groupBox1.Controls.Add(this.lblDisplayUserName);
            this.groupBox1.Controls.Add(this.lblUserName);
            this.groupBox1.Controls.Add(this.lblDisplayUserID);
            this.groupBox1.Controls.Add(this.lblUserID);
            this.groupBox1.Controls.Add(this.txtConfirmPassword);
            this.groupBox1.Controls.Add(this.lblNewPassword);
            this.groupBox1.Controls.Add(this.txtNewPassword);
            this.groupBox1.Controls.Add(this.lblConfirmPassword);
            this.groupBox1.Controls.Add(this.btnChangePassword);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(80, 575);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 242);
            this.groupBox1.TabIndex = 53;
            this.groupBox1.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(56)))));
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(235, 196);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(122, 25);
            this.btnExit.TabIndex = 17;
            this.btnExit.Text = "EXIT";
            this.btnExit.UseVisualStyleBackColor = false;
            // 
            // ForgotPasswordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SandyBrown;
            this.ClientSize = new System.Drawing.Size(665, 835);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmbSecurityQuestion5);
            this.Controls.Add(this.txtAnswer5);
            this.Controls.Add(this.lblAns5);
            this.Controls.Add(this.lblSecurityQuestion5);
            this.Controls.Add(this.cmbSecurityQuestion4);
            this.Controls.Add(this.txtAnswer4);
            this.Controls.Add(this.lblAns4);
            this.Controls.Add(this.lblSecurityQuestion4);
            this.Controls.Add(this.cmbSecurityQuestion3);
            this.Controls.Add(this.txtAnswer3);
            this.Controls.Add(this.lblAns3);
            this.Controls.Add(this.lblSecurityQuestion3);
            this.Controls.Add(this.cmbSecurityQuestion2);
            this.Controls.Add(this.txtAnswer2);
            this.Controls.Add(this.lblAns2);
            this.Controls.Add(this.lblSecurityQuestion2);
            this.Controls.Add(this.cmbSecurityQuestion1);
            this.Controls.Add(this.txtAnswer1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnSubmitAnswer);
            this.Controls.Add(this.lblAns1);
            this.Controls.Add(this.lblSecurityQuestion1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblPwdChng);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "ForgotPasswordForm";
            this.Text = "Reset Your Password";
            this.Load += new System.EventHandler(this.ForgotPasswordForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAnswer1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnSubmitAnswer;
        private System.Windows.Forms.Label lblAns1;
        private System.Windows.Forms.Label lblSecurityQuestion1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPwdChng;
        private System.Windows.Forms.ComboBox cmbSecurityQuestion1;
        private System.Windows.Forms.ComboBox cmbSecurityQuestion2;
        private System.Windows.Forms.TextBox txtAnswer2;
        private System.Windows.Forms.Label lblAns2;
        private System.Windows.Forms.Label lblSecurityQuestion2;
        private System.Windows.Forms.ComboBox cmbSecurityQuestion3;
        private System.Windows.Forms.TextBox txtAnswer3;
        private System.Windows.Forms.Label lblAns3;
        private System.Windows.Forms.Label lblSecurityQuestion3;
        private System.Windows.Forms.ComboBox cmbSecurityQuestion4;
        private System.Windows.Forms.TextBox txtAnswer4;
        private System.Windows.Forms.Label lblAns4;
        private System.Windows.Forms.Label lblSecurityQuestion4;
        private System.Windows.Forms.ComboBox cmbSecurityQuestion5;
        private System.Windows.Forms.TextBox txtAnswer5;
        private System.Windows.Forms.Label lblAns5;
        private System.Windows.Forms.Label lblSecurityQuestion5;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.Button btnChangePassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.Label lblNewPassword;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label lblPasswordChange;
        private System.Windows.Forms.Label lblDisplayUserID;
        private System.Windows.Forms.Label lblDisplayUserName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.BindingSource bindingSource1;
    }
}