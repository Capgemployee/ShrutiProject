﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Management_System
{
    public partial class ForgotPasswordForm : Form
    {
        public ForgotPasswordForm()
        {
            InitializeComponent();
        }

        private void ForgotPasswordForm_Load(object sender, EventArgs e)
        {
            string[] securityQuestionsList = new string[]{
                "------ Select Security Question ------",

            "What is the first and last name of your first boyfriend or girlfriend?",

            "Which phone number do you remember most from your childhood?",

            "What was your favorite place to visit as a child?",

            "Who is your favorite actor, musician, or artist?",

            "What is the name of your favorite pet?",

            "In what city were you born?",

            "What high school did you attend?",

            "What is the name of your first school?",

            "What is your favorite movie?",

            "What is your mother's maiden name?",

            "What street did you grow up on?",

            "What was the make of your first car?",

            "When is your anniversary?",

            "What is your favorite color?",

            "What is your father's middle name?",

            "What is the name of your first grade teacher?",

            "What was your high school mascot?",

            "Which is your favorite web browser?"

            };
            this.Height=200;
            this.Width =644 ;
            cmbSecurityQuestion1.Hide();
            lblSecurityQuestion1.Hide();
            lblSecurityQuestion2.Hide();
            lblSecurityQuestion3.Hide();
            lblSecurityQuestion4.Hide();
            lblSecurityQuestion5.Hide();

            cmbSecurityQuestion1.Hide();
            cmbSecurityQuestion2.Hide();
            cmbSecurityQuestion3.Hide();
            cmbSecurityQuestion4.Hide();
            cmbSecurityQuestion5.Hide();

            lblAns1.Hide();
            lblAns2.Hide();
            lblAns3.Hide();
            lblAns4.Hide();
            lblAns5.Hide();

            txtAnswer1.Hide();
            txtAnswer2.Hide();
            txtAnswer3.Hide();
            txtAnswer4.Hide();
            txtAnswer5.Hide();

            btnSubmitAnswer.Hide();
      

            cmbSecurityQuestion1.DataSource = securityQuestionsList.ToList();
            cmbSecurityQuestion2.DataSource = securityQuestionsList.ToList();
            cmbSecurityQuestion3.DataSource = securityQuestionsList.ToList();
            cmbSecurityQuestion4.DataSource = securityQuestionsList.ToList();
            cmbSecurityQuestion5.DataSource = securityQuestionsList.ToList();

            cmbSecurityQuestion1.SelectedIndex = 0;
            


            groupBox1.Hide();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;

        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            lblAns1.Show();
            txtAnswer1.Show();
            cmbSecurityQuestion1.Show();
            lblSecurityQuestion1.Show();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            cmbSecurityQuestion1.SelectedIndex = 0;

        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            lblAns1.Show();
            txtAnswer1.Show();
            cmbSecurityQuestion1.Show();
            lblSecurityQuestion1.Show();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            cmbSecurityQuestion1.SelectedIndex = 0;
        }

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
           

        }

        private void txtAnswer1_Leave(object sender, EventArgs e)
        {
            lblAns2.Show();
            txtAnswer2.Show();
            cmbSecurityQuestion2.Show();
            lblSecurityQuestion2.Show();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            cmbSecurityQuestion2.SelectedIndex = 0;
        }

        private void txtAnswer1_TextChanged(object sender, EventArgs e)
        {

            this.Height = 315;
            this.Width = 644;
            cmbSecurityQuestion2.Show();
            lblSecurityQuestion2.Show();
            txtAnswer2.Show();
            lblAns2.Show();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            cmbSecurityQuestion2.SelectedIndex = 0;
        }

        private void txtAnswer2_TextChanged(object sender, EventArgs e)
        {

            this.Height = 390;
            this.Width = 644;
            cmbSecurityQuestion3.Show();
            lblSecurityQuestion3.Show();
            txtAnswer3.Show();
            lblAns3.Show();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            cmbSecurityQuestion3.SelectedIndex = 0;
        }

        private void txtAnswer3_TextChanged(object sender, EventArgs e)
        {

            this.Height = 460;
            this.Width = 644;
            cmbSecurityQuestion4.Show();
            lblSecurityQuestion4.Show();
            txtAnswer4.Show();
            lblAns4.Show();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            cmbSecurityQuestion4.SelectedIndex = 0;
        }

        private void txtAnswer4_TextChanged(object sender, EventArgs e)
        {

            this.Height = 535;
            this.Width = 644;
            cmbSecurityQuestion5.Show();
            lblSecurityQuestion5.Show();
            txtAnswer5.Show();
            lblAns5.Show();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            cmbSecurityQuestion5.SelectedIndex = 0;
        }

        private void txtAnswer5_TextChanged(object sender, EventArgs e)
        {

            this.Height = 596;
            this.Width = 644;
            cmbSecurityQuestion1.Show();
            lblSecurityQuestion1.Show();
            txtAnswer1.Show();
            lblAns1.Show();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            btnSubmitAnswer.Show();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            textBox1.Hide();
            textBox2.Hide();

            cmbSecurityQuestion1.Hide();
            lblSecurityQuestion1.Hide();
            lblSecurityQuestion2.Hide();
            lblSecurityQuestion3.Hide();
            lblSecurityQuestion4.Hide();
            lblSecurityQuestion5.Hide();

            cmbSecurityQuestion1.Hide();
            cmbSecurityQuestion2.Hide();
            cmbSecurityQuestion3.Hide();
            cmbSecurityQuestion4.Hide();
            cmbSecurityQuestion5.Hide();

            lblAns1.Hide();
            lblAns2.Hide();
            lblAns3.Hide();
            lblAns4.Hide();
            lblAns5.Hide();

            txtAnswer1.Hide();
            txtAnswer2.Hide();
            txtAnswer3.Hide();
            txtAnswer4.Hide();
            txtAnswer5.Hide();

            btnSubmitAnswer.Hide();
        

            lblPwdChng.Hide();
            label2.Hide();
            label3.Hide();

            groupBox1.Show();
            groupBox1.Left = 10;
            groupBox1.Top = 10;
            this.Width = 445;
            this.Height = 300;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            this.Height = 245;
            this.Width = 644;
            cmbSecurityQuestion1.Show();
            lblSecurityQuestion1.Show();
            txtAnswer1.Show();
            lblAns1.Show();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            
        }

        private void lblPwdChng_Click(object sender, EventArgs e)
        {

        }

        private void btnChangePassword_Click_1(object sender, EventArgs e)
        {
            LoginForm1 objLoginForm1 = new LoginForm1();
            objLoginForm1.Show();
            this.Hide();
            ParentForm.Close();
        }

  
    

  
    }
}
