﻿namespace Employee_Management_System
{
    partial class HRPortalPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HRPortalPage));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.datagridShowData = new System.Windows.Forms.DataGridView();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.lblDeptId = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.txtxSearchByEmpID = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblSalary = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblDesignation = new System.Windows.Forms.Label();
            this.lblDOJ = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblContactNo = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblSkill = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label55 = new System.Windows.Forms.Label();
            this.txtDeptId = new System.Windows.Forms.TextBox();
            this.btnAddEmp = new System.Windows.Forms.Button();
            this.radioOther = new System.Windows.Forms.RadioButton();
            this.radioFemale = new System.Windows.Forms.RadioButton();
            this.radioMale = new System.Windows.Forms.RadioButton();
            this.txtDOJ = new System.Windows.Forms.TextBox();
            this.txtDOB = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtContactNo = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtDesignation = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtSkill = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label42 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label43 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnAcceptLeave = new System.Windows.Forms.Button();
            this.btnDeclineLeave = new System.Windows.Forms.Button();
            this.btnApprovedLeave = new System.Windows.Forms.Button();
            this.btnPendingLEave = new System.Windows.Forms.Button();
            this.datagridLeaves = new System.Windows.Forms.DataGridView();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.lblShowFirstName = new System.Windows.Forms.Label();
            this.lblShowSalary = new System.Windows.Forms.Label();
            this.lblShowGender = new System.Windows.Forms.Label();
            this.lblShowDesignation = new System.Windows.Forms.Label();
            this.lblShowDOJ = new System.Windows.Forms.Label();
            this.lblShowEmail = new System.Windows.Forms.Label();
            this.lblShowLastName = new System.Windows.Forms.Label();
            this.lblShowDOB = new System.Windows.Forms.Label();
            this.lblShowAge = new System.Windows.Forms.Label();
            this.lblShowContactNo = new System.Windows.Forms.Label();
            this.lblShowAddress = new System.Windows.Forms.Label();
            this.lblShowEmpID = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.datagridBirthday = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label74 = new System.Windows.Forms.Label();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.radioButton27 = new System.Windows.Forms.RadioButton();
            this.radioButton28 = new System.Windows.Forms.RadioButton();
            this.radioButton29 = new System.Windows.Forms.RadioButton();
            this.radioButton30 = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label84 = new System.Windows.Forms.Label();
            this.radioButton73 = new System.Windows.Forms.RadioButton();
            this.radioButton74 = new System.Windows.Forms.RadioButton();
            this.radioButton75 = new System.Windows.Forms.RadioButton();
            this.radioButton76 = new System.Windows.Forms.RadioButton();
            this.radioButton77 = new System.Windows.Forms.RadioButton();
            this.radioButton78 = new System.Windows.Forms.RadioButton();
            this.label80 = new System.Windows.Forms.Label();
            this.radioButton49 = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label83 = new System.Windows.Forms.Label();
            this.radioButton55 = new System.Windows.Forms.RadioButton();
            this.radioButton56 = new System.Windows.Forms.RadioButton();
            this.radioButton57 = new System.Windows.Forms.RadioButton();
            this.radioButton58 = new System.Windows.Forms.RadioButton();
            this.radioButton59 = new System.Windows.Forms.RadioButton();
            this.radioButton60 = new System.Windows.Forms.RadioButton();
            this.radioButton61 = new System.Windows.Forms.RadioButton();
            this.radioButton62 = new System.Windows.Forms.RadioButton();
            this.radioButton63 = new System.Windows.Forms.RadioButton();
            this.radioButton64 = new System.Windows.Forms.RadioButton();
            this.radioButton65 = new System.Windows.Forms.RadioButton();
            this.radioButton66 = new System.Windows.Forms.RadioButton();
            this.radioButton67 = new System.Windows.Forms.RadioButton();
            this.radioButton68 = new System.Windows.Forms.RadioButton();
            this.radioButton69 = new System.Windows.Forms.RadioButton();
            this.radioButton70 = new System.Windows.Forms.RadioButton();
            this.radioButton71 = new System.Windows.Forms.RadioButton();
            this.radioButton72 = new System.Windows.Forms.RadioButton();
            this.radioButton50 = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.label81 = new System.Windows.Forms.Label();
            this.radioButton51 = new System.Windows.Forms.RadioButton();
            this.radioButton52 = new System.Windows.Forms.RadioButton();
            this.radioButton53 = new System.Windows.Forms.RadioButton();
            this.radioButton54 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label72 = new System.Windows.Forms.Label();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label76 = new System.Windows.Forms.Label();
            this.groupBoxPassword = new System.Windows.Forms.GroupBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label75 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.label85 = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridShowData)).BeginInit();
            this.tabPage9.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridLeaves)).BeginInit();
            this.tabPage10.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridBirthday)).BeginInit();
            this.tabPage11.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBoxPassword.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 119);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(980, 595);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.datagridShowData);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(972, 566);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "List of Employees";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // datagridShowData
            // 
            this.datagridShowData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridShowData.Location = new System.Drawing.Point(6, 6);
            this.datagridShowData.Name = "datagridShowData";
            this.datagridShowData.Size = new System.Drawing.Size(948, 554);
            this.datagridShowData.TabIndex = 2;
            this.datagridShowData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datagridShowData_CellContentClick);
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.lblDeptId);
            this.tabPage9.Controls.Add(this.label44);
            this.tabPage9.Controls.Add(this.button5);
            this.tabPage9.Controls.Add(this.txtxSearchByEmpID);
            this.tabPage9.Controls.Add(this.label69);
            this.tabPage9.Controls.Add(this.lblFirstName);
            this.tabPage9.Controls.Add(this.lblSalary);
            this.tabPage9.Controls.Add(this.lblGender);
            this.tabPage9.Controls.Add(this.lblDesignation);
            this.tabPage9.Controls.Add(this.lblDOJ);
            this.tabPage9.Controls.Add(this.lblEmail);
            this.tabPage9.Controls.Add(this.lblLastName);
            this.tabPage9.Controls.Add(this.lblDOB);
            this.tabPage9.Controls.Add(this.lblAge);
            this.tabPage9.Controls.Add(this.lblContactNo);
            this.tabPage9.Controls.Add(this.lblAddress);
            this.tabPage9.Controls.Add(this.lblSkill);
            this.tabPage9.Controls.Add(this.label56);
            this.tabPage9.Controls.Add(this.label57);
            this.tabPage9.Controls.Add(this.label58);
            this.tabPage9.Controls.Add(this.label59);
            this.tabPage9.Controls.Add(this.label60);
            this.tabPage9.Controls.Add(this.label61);
            this.tabPage9.Controls.Add(this.label62);
            this.tabPage9.Controls.Add(this.label63);
            this.tabPage9.Controls.Add(this.label64);
            this.tabPage9.Controls.Add(this.label65);
            this.tabPage9.Controls.Add(this.label66);
            this.tabPage9.Controls.Add(this.label67);
            this.tabPage9.Controls.Add(this.label68);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(972, 566);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Search Employee";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // lblDeptId
            // 
            this.lblDeptId.AutoSize = true;
            this.lblDeptId.Location = new System.Drawing.Point(305, 518);
            this.lblDeptId.Name = "lblDeptId";
            this.lblDeptId.Size = new System.Drawing.Size(52, 16);
            this.lblDeptId.TabIndex = 81;
            this.lblDeptId.Text = "label42";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(170, 518);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(53, 16);
            this.label44.TabIndex = 80;
            this.label44.Text = "Dept ID";
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(362, 23);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(122, 28);
            this.button5.TabIndex = 79;
            this.button5.Text = "Show Details";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // txtxSearchByEmpID
            // 
            this.txtxSearchByEmpID.Location = new System.Drawing.Point(176, 31);
            this.txtxSearchByEmpID.Name = "txtxSearchByEmpID";
            this.txtxSearchByEmpID.Size = new System.Drawing.Size(162, 22);
            this.txtxSearchByEmpID.TabIndex = 78;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(26, 33);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(144, 18);
            this.label69.TabIndex = 77;
            this.label69.Text = "Enter Employee ID :-";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(308, 275);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(52, 16);
            this.lblFirstName.TabIndex = 76;
            this.lblFirstName.Text = "label53";
            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.Location = new System.Drawing.Point(308, 477);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(52, 16);
            this.lblSalary.TabIndex = 75;
            this.lblSalary.Text = "label52";
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(755, 228);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(52, 16);
            this.lblGender.TabIndex = 74;
            this.lblGender.Text = "label51";
            // 
            // lblDesignation
            // 
            this.lblDesignation.AutoSize = true;
            this.lblDesignation.Location = new System.Drawing.Point(755, 327);
            this.lblDesignation.Name = "lblDesignation";
            this.lblDesignation.Size = new System.Drawing.Size(52, 16);
            this.lblDesignation.TabIndex = 73;
            this.lblDesignation.Text = "label50";
            // 
            // lblDOJ
            // 
            this.lblDOJ.AutoSize = true;
            this.lblDOJ.Location = new System.Drawing.Point(308, 428);
            this.lblDOJ.Name = "lblDOJ";
            this.lblDOJ.Size = new System.Drawing.Size(52, 16);
            this.lblDOJ.TabIndex = 72;
            this.lblDOJ.Text = "label49";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(755, 376);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(52, 16);
            this.lblEmail.TabIndex = 71;
            this.lblEmail.Text = "label48";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(308, 327);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(52, 16);
            this.lblLastName.TabIndex = 70;
            this.lblLastName.Text = "label47";
            // 
            // lblDOB
            // 
            this.lblDOB.AutoSize = true;
            this.lblDOB.Location = new System.Drawing.Point(308, 376);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(52, 16);
            this.lblDOB.TabIndex = 69;
            this.lblDOB.Text = "label46";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(755, 275);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(52, 16);
            this.lblAge.TabIndex = 68;
            this.lblAge.Text = "label45";
            // 
            // lblContactNo
            // 
            this.lblContactNo.AutoSize = true;
            this.lblContactNo.Location = new System.Drawing.Point(755, 428);
            this.lblContactNo.Name = "lblContactNo";
            this.lblContactNo.Size = new System.Drawing.Size(52, 16);
            this.lblContactNo.TabIndex = 67;
            this.lblContactNo.Text = "label44";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(755, 477);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(52, 16);
            this.lblAddress.TabIndex = 66;
            this.lblAddress.Text = "label43";
            // 
            // lblSkill
            // 
            this.lblSkill.AutoSize = true;
            this.lblSkill.Location = new System.Drawing.Point(308, 228);
            this.lblSkill.Name = "lblSkill";
            this.lblSkill.Size = new System.Drawing.Size(52, 16);
            this.lblSkill.TabIndex = 65;
            this.lblSkill.Text = "label42";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(173, 228);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(40, 16);
            this.label56.TabIndex = 64;
            this.label56.Text = "Skills";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(173, 327);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(73, 16);
            this.label57.TabIndex = 63;
            this.label57.Text = "Last Name";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(173, 376);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(37, 16);
            this.label58.TabIndex = 62;
            this.label58.Text = "DOB";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(622, 228);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(53, 16);
            this.label59.TabIndex = 61;
            this.label59.Text = "Gender";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(622, 327);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(80, 16);
            this.label60.TabIndex = 60;
            this.label60.Text = "Designation";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(622, 428);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(74, 16);
            this.label61.TabIndex = 59;
            this.label61.Text = "Contact No";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(173, 275);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(73, 16);
            this.label62.TabIndex = 58;
            this.label62.Text = "First Name";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(173, 428);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(35, 16);
            this.label63.TabIndex = 57;
            this.label63.Text = "DOJ";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(173, 477);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(47, 16);
            this.label64.TabIndex = 56;
            this.label64.Text = "Salary";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(622, 275);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(33, 16);
            this.label65.TabIndex = 55;
            this.label65.Text = "Age";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(622, 376);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(42, 16);
            this.label66.TabIndex = 54;
            this.label66.Text = "Email";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(622, 477);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(59, 16);
            this.label67.TabIndex = 53;
            this.label67.Text = "Address";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(397, 132);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(213, 24);
            this.label68.TabIndex = 52;
            this.label68.Text = "Employee Information";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label55);
            this.tabPage2.Controls.Add(this.txtDeptId);
            this.tabPage2.Controls.Add(this.btnAddEmp);
            this.tabPage2.Controls.Add(this.radioOther);
            this.tabPage2.Controls.Add(this.radioFemale);
            this.tabPage2.Controls.Add(this.radioMale);
            this.tabPage2.Controls.Add(this.txtDOJ);
            this.tabPage2.Controls.Add(this.txtDOB);
            this.tabPage2.Controls.Add(this.txtAddress);
            this.tabPage2.Controls.Add(this.txtContactNo);
            this.tabPage2.Controls.Add(this.txtEmail);
            this.tabPage2.Controls.Add(this.txtDesignation);
            this.tabPage2.Controls.Add(this.txtAge);
            this.tabPage2.Controls.Add(this.txtSalary);
            this.tabPage2.Controls.Add(this.txtLastName);
            this.tabPage2.Controls.Add(this.txtFirstName);
            this.tabPage2.Controls.Add(this.txtSkill);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(972, 566);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Hire Employee";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(65, 399);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(53, 16);
            this.label55.TabIndex = 28;
            this.label55.Text = "Dept ID";
            // 
            // txtDeptId
            // 
            this.txtDeptId.Location = new System.Drawing.Point(159, 391);
            this.txtDeptId.Name = "txtDeptId";
            this.txtDeptId.Size = new System.Drawing.Size(255, 22);
            this.txtDeptId.TabIndex = 27;
            // 
            // btnAddEmp
            // 
            this.btnAddEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEmp.Location = new System.Drawing.Point(302, 481);
            this.btnAddEmp.Name = "btnAddEmp";
            this.btnAddEmp.Size = new System.Drawing.Size(121, 37);
            this.btnAddEmp.TabIndex = 4;
            this.btnAddEmp.Text = "Save";
            this.btnAddEmp.UseVisualStyleBackColor = true;
            this.btnAddEmp.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // radioOther
            // 
            this.radioOther.AutoSize = true;
            this.radioOther.Location = new System.Drawing.Point(767, 105);
            this.radioOther.Name = "radioOther";
            this.radioOther.Size = new System.Drawing.Size(58, 20);
            this.radioOther.TabIndex = 26;
            this.radioOther.TabStop = true;
            this.radioOther.Text = "Other";
            this.radioOther.UseVisualStyleBackColor = true;
            // 
            // radioFemale
            // 
            this.radioFemale.AutoSize = true;
            this.radioFemale.Location = new System.Drawing.Point(689, 105);
            this.radioFemale.Name = "radioFemale";
            this.radioFemale.Size = new System.Drawing.Size(72, 20);
            this.radioFemale.TabIndex = 25;
            this.radioFemale.TabStop = true;
            this.radioFemale.Text = "Female";
            this.radioFemale.UseVisualStyleBackColor = true;
            // 
            // radioMale
            // 
            this.radioMale.AutoSize = true;
            this.radioMale.Location = new System.Drawing.Point(618, 106);
            this.radioMale.Name = "radioMale";
            this.radioMale.Size = new System.Drawing.Size(56, 20);
            this.radioMale.TabIndex = 24;
            this.radioMale.TabStop = true;
            this.radioMale.Text = "Male";
            this.radioMale.UseVisualStyleBackColor = true;
            // 
            // txtDOJ
            // 
            this.txtDOJ.Location = new System.Drawing.Point(159, 303);
            this.txtDOJ.Name = "txtDOJ";
            this.txtDOJ.Size = new System.Drawing.Size(255, 22);
            this.txtDOJ.TabIndex = 23;
            // 
            // txtDOB
            // 
            this.txtDOB.Location = new System.Drawing.Point(159, 254);
            this.txtDOB.Name = "txtDOB";
            this.txtDOB.Size = new System.Drawing.Size(255, 22);
            this.txtDOB.TabIndex = 22;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(609, 358);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(255, 54);
            this.txtAddress.TabIndex = 21;
            // 
            // txtContactNo
            // 
            this.txtContactNo.Location = new System.Drawing.Point(609, 309);
            this.txtContactNo.Name = "txtContactNo";
            this.txtContactNo.Size = new System.Drawing.Size(255, 22);
            this.txtContactNo.TabIndex = 20;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(609, 257);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(255, 22);
            this.txtEmail.TabIndex = 19;
            // 
            // txtDesignation
            // 
            this.txtDesignation.Location = new System.Drawing.Point(609, 205);
            this.txtDesignation.Name = "txtDesignation";
            this.txtDesignation.Size = new System.Drawing.Size(255, 22);
            this.txtDesignation.TabIndex = 18;
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(609, 156);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(255, 22);
            this.txtAge.TabIndex = 17;
            // 
            // txtSalary
            // 
            this.txtSalary.Location = new System.Drawing.Point(159, 352);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(255, 22);
            this.txtSalary.TabIndex = 16;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(159, 202);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(255, 22);
            this.txtLastName.TabIndex = 15;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(159, 156);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(255, 22);
            this.txtFirstName.TabIndex = 14;
            // 
            // txtSkill
            // 
            this.txtSkill.Location = new System.Drawing.Point(159, 106);
            this.txtSkill.Name = "txtSkill";
            this.txtSkill.Size = new System.Drawing.Size(255, 22);
            this.txtSkill.TabIndex = 13;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(62, 109);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 16);
            this.label15.TabIndex = 12;
            this.label15.Text = "Skills";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(62, 208);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 16);
            this.label14.TabIndex = 11;
            this.label14.Text = "Last Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(62, 257);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 16);
            this.label13.TabIndex = 10;
            this.label13.Text = "DOB";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(511, 109);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 16);
            this.label12.TabIndex = 9;
            this.label12.Text = "Gender";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(511, 208);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "Designation";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(511, 309);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 16);
            this.label10.TabIndex = 7;
            this.label10.Text = "Contact No";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(62, 156);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 16);
            this.label9.TabIndex = 6;
            this.label9.Text = "First Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(62, 309);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 16);
            this.label8.TabIndex = 5;
            this.label8.Text = "DOJ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(62, 358);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 16);
            this.label7.TabIndex = 4;
            this.label7.Text = "Salary";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(511, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "Age";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(511, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(511, 358);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(329, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(262, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "New Employee Application";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Controls.Add(this.textBox22);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label28);
            this.tabPage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(972, 566);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Fired Employee";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(496, 220);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(121, 37);
            this.button3.TabIndex = 56;
            this.button3.Text = "Cancel";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(318, 220);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(121, 37);
            this.button4.TabIndex = 32;
            this.button4.Text = "Save";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(397, 131);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(255, 22);
            this.textBox22.TabIndex = 42;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(280, 134);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 16);
            this.label16.TabIndex = 41;
            this.label16.Text = "Emp ID";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(347, 38);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(285, 24);
            this.label28.TabIndex = 28;
            this.label28.Text = "Resign Employee Application";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.label42);
            this.tabPage7.Controls.Add(this.dataGridView1);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(972, 566);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Today Present Employees";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(330, 11);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(270, 24);
            this.label42.TabIndex = 4;
            this.label42.Text = "Today\'s Present Employees";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 47);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(939, 505);
            this.dataGridView1.TabIndex = 3;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label43);
            this.tabPage8.Controls.Add(this.dataGridView2);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(972, 566);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Today Absent Employees";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(327, 11);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(264, 24);
            this.label43.TabIndex = 5;
            this.label43.Text = "Today\'s Absent Employees";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(18, 47);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(937, 505);
            this.dataGridView2.TabIndex = 4;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnAcceptLeave);
            this.tabPage4.Controls.Add(this.btnDeclineLeave);
            this.tabPage4.Controls.Add(this.btnApprovedLeave);
            this.tabPage4.Controls.Add(this.btnPendingLEave);
            this.tabPage4.Controls.Add(this.datagridLeaves);
            this.tabPage4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(972, 566);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Leave Management";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnAcceptLeave
            // 
            this.btnAcceptLeave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAcceptLeave.Location = new System.Drawing.Point(310, 30);
            this.btnAcceptLeave.Name = "btnAcceptLeave";
            this.btnAcceptLeave.Size = new System.Drawing.Size(119, 25);
            this.btnAcceptLeave.TabIndex = 7;
            this.btnAcceptLeave.Text = "Accept Leave";
            this.btnAcceptLeave.UseVisualStyleBackColor = true;
            // 
            // btnDeclineLeave
            // 
            this.btnDeclineLeave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeclineLeave.Location = new System.Drawing.Point(459, 30);
            this.btnDeclineLeave.Name = "btnDeclineLeave";
            this.btnDeclineLeave.Size = new System.Drawing.Size(119, 25);
            this.btnDeclineLeave.TabIndex = 6;
            this.btnDeclineLeave.Text = "Decline Leave";
            this.btnDeclineLeave.UseVisualStyleBackColor = true;
            // 
            // btnApprovedLeave
            // 
            this.btnApprovedLeave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApprovedLeave.Location = new System.Drawing.Point(164, 30);
            this.btnApprovedLeave.Name = "btnApprovedLeave";
            this.btnApprovedLeave.Size = new System.Drawing.Size(119, 25);
            this.btnApprovedLeave.TabIndex = 5;
            this.btnApprovedLeave.Text = "Approved Leaves";
            this.btnApprovedLeave.UseVisualStyleBackColor = true;
            this.btnApprovedLeave.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnPendingLEave
            // 
            this.btnPendingLEave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPendingLEave.Location = new System.Drawing.Point(14, 30);
            this.btnPendingLEave.Name = "btnPendingLEave";
            this.btnPendingLEave.Size = new System.Drawing.Size(119, 25);
            this.btnPendingLEave.TabIndex = 4;
            this.btnPendingLEave.Text = "Pending Leaves";
            this.btnPendingLEave.UseVisualStyleBackColor = true;
            // 
            // datagridLeaves
            // 
            this.datagridLeaves.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridLeaves.Location = new System.Drawing.Point(14, 78);
            this.datagridLeaves.Name = "datagridLeaves";
            this.datagridLeaves.Size = new System.Drawing.Size(945, 475);
            this.datagridLeaves.TabIndex = 4;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.textBox27);
            this.tabPage10.Controls.Add(this.label71);
            this.tabPage10.Controls.Add(this.button6);
            this.tabPage10.Controls.Add(this.button7);
            this.tabPage10.Controls.Add(this.textBox24);
            this.tabPage10.Controls.Add(this.textBox25);
            this.tabPage10.Controls.Add(this.textBox26);
            this.tabPage10.Controls.Add(this.textBox31);
            this.tabPage10.Controls.Add(this.label73);
            this.tabPage10.Controls.Add(this.label78);
            this.tabPage10.Controls.Add(this.label79);
            this.tabPage10.Controls.Add(this.label82);
            this.tabPage10.Controls.Add(this.label70);
            this.tabPage10.Location = new System.Drawing.Point(4, 25);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(972, 566);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "Apply Leave";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(386, 235);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(255, 22);
            this.textBox27.TabIndex = 57;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(289, 242);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(81, 16);
            this.label71.TabIndex = 56;
            this.label71.Text = "Leave Type";
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(510, 396);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(121, 37);
            this.button6.TabIndex = 55;
            this.button6.Text = "Cancel";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(292, 396);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(121, 37);
            this.button7.TabIndex = 31;
            this.button7.Text = "Apply";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(386, 137);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(255, 22);
            this.textBox24.TabIndex = 51;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(386, 92);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(255, 22);
            this.textBox25.TabIndex = 50;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(386, 285);
            this.textBox26.Multiline = true;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(255, 54);
            this.textBox26.TabIndex = 49;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(386, 188);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(255, 22);
            this.textBox31.TabIndex = 44;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(289, 92);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(71, 16);
            this.label73.TabIndex = 38;
            this.label73.Text = "From Date";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(289, 140);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(57, 16);
            this.label78.TabIndex = 33;
            this.label78.Text = "To Date";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(289, 195);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(78, 16);
            this.label79.TabIndex = 32;
            this.label79.Text = "Total Hours";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(289, 285);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(72, 16);
            this.label82.TabIndex = 28;
            this.label82.Text = "Comments";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(398, 32);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(125, 24);
            this.label70.TabIndex = 6;
            this.label70.Text = "Apply Leave";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.lblShowFirstName);
            this.tabPage5.Controls.Add(this.lblShowSalary);
            this.tabPage5.Controls.Add(this.lblShowGender);
            this.tabPage5.Controls.Add(this.lblShowDesignation);
            this.tabPage5.Controls.Add(this.lblShowDOJ);
            this.tabPage5.Controls.Add(this.lblShowEmail);
            this.tabPage5.Controls.Add(this.lblShowLastName);
            this.tabPage5.Controls.Add(this.lblShowDOB);
            this.tabPage5.Controls.Add(this.lblShowAge);
            this.tabPage5.Controls.Add(this.lblShowContactNo);
            this.tabPage5.Controls.Add(this.lblShowAddress);
            this.tabPage5.Controls.Add(this.lblShowEmpID);
            this.tabPage5.Controls.Add(this.label29);
            this.tabPage5.Controls.Add(this.label30);
            this.tabPage5.Controls.Add(this.label31);
            this.tabPage5.Controls.Add(this.label32);
            this.tabPage5.Controls.Add(this.label33);
            this.tabPage5.Controls.Add(this.label34);
            this.tabPage5.Controls.Add(this.label35);
            this.tabPage5.Controls.Add(this.label36);
            this.tabPage5.Controls.Add(this.label37);
            this.tabPage5.Controls.Add(this.label38);
            this.tabPage5.Controls.Add(this.label39);
            this.tabPage5.Controls.Add(this.label40);
            this.tabPage5.Controls.Add(this.label41);
            this.tabPage5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(972, 566);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "My Info";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // lblShowFirstName
            // 
            this.lblShowFirstName.AutoSize = true;
            this.lblShowFirstName.Location = new System.Drawing.Point(281, 169);
            this.lblShowFirstName.Name = "lblShowFirstName";
            this.lblShowFirstName.Size = new System.Drawing.Size(54, 18);
            this.lblShowFirstName.TabIndex = 51;
            this.lblShowFirstName.Text = "label53";
            // 
            // lblShowSalary
            // 
            this.lblShowSalary.AutoSize = true;
            this.lblShowSalary.Location = new System.Drawing.Point(281, 371);
            this.lblShowSalary.Name = "lblShowSalary";
            this.lblShowSalary.Size = new System.Drawing.Size(54, 18);
            this.lblShowSalary.TabIndex = 50;
            this.lblShowSalary.Text = "label52";
            // 
            // lblShowGender
            // 
            this.lblShowGender.AutoSize = true;
            this.lblShowGender.Location = new System.Drawing.Point(728, 122);
            this.lblShowGender.Name = "lblShowGender";
            this.lblShowGender.Size = new System.Drawing.Size(54, 18);
            this.lblShowGender.TabIndex = 49;
            this.lblShowGender.Text = "label51";
            // 
            // lblShowDesignation
            // 
            this.lblShowDesignation.AutoSize = true;
            this.lblShowDesignation.Location = new System.Drawing.Point(728, 221);
            this.lblShowDesignation.Name = "lblShowDesignation";
            this.lblShowDesignation.Size = new System.Drawing.Size(54, 18);
            this.lblShowDesignation.TabIndex = 48;
            this.lblShowDesignation.Text = "label50";
            // 
            // lblShowDOJ
            // 
            this.lblShowDOJ.AutoSize = true;
            this.lblShowDOJ.Location = new System.Drawing.Point(281, 322);
            this.lblShowDOJ.Name = "lblShowDOJ";
            this.lblShowDOJ.Size = new System.Drawing.Size(54, 18);
            this.lblShowDOJ.TabIndex = 47;
            this.lblShowDOJ.Text = "label49";
            // 
            // lblShowEmail
            // 
            this.lblShowEmail.AutoSize = true;
            this.lblShowEmail.Location = new System.Drawing.Point(728, 270);
            this.lblShowEmail.Name = "lblShowEmail";
            this.lblShowEmail.Size = new System.Drawing.Size(54, 18);
            this.lblShowEmail.TabIndex = 46;
            this.lblShowEmail.Text = "label48";
            // 
            // lblShowLastName
            // 
            this.lblShowLastName.AutoSize = true;
            this.lblShowLastName.Location = new System.Drawing.Point(281, 221);
            this.lblShowLastName.Name = "lblShowLastName";
            this.lblShowLastName.Size = new System.Drawing.Size(54, 18);
            this.lblShowLastName.TabIndex = 45;
            this.lblShowLastName.Text = "label47";
            // 
            // lblShowDOB
            // 
            this.lblShowDOB.AutoSize = true;
            this.lblShowDOB.Location = new System.Drawing.Point(281, 270);
            this.lblShowDOB.Name = "lblShowDOB";
            this.lblShowDOB.Size = new System.Drawing.Size(54, 18);
            this.lblShowDOB.TabIndex = 44;
            this.lblShowDOB.Text = "label46";
            // 
            // lblShowAge
            // 
            this.lblShowAge.AutoSize = true;
            this.lblShowAge.Location = new System.Drawing.Point(728, 169);
            this.lblShowAge.Name = "lblShowAge";
            this.lblShowAge.Size = new System.Drawing.Size(54, 18);
            this.lblShowAge.TabIndex = 43;
            this.lblShowAge.Text = "label45";
            // 
            // lblShowContactNo
            // 
            this.lblShowContactNo.AutoSize = true;
            this.lblShowContactNo.Location = new System.Drawing.Point(728, 322);
            this.lblShowContactNo.Name = "lblShowContactNo";
            this.lblShowContactNo.Size = new System.Drawing.Size(54, 18);
            this.lblShowContactNo.TabIndex = 42;
            this.lblShowContactNo.Text = "label44";
            // 
            // lblShowAddress
            // 
            this.lblShowAddress.AutoSize = true;
            this.lblShowAddress.Location = new System.Drawing.Point(728, 371);
            this.lblShowAddress.Name = "lblShowAddress";
            this.lblShowAddress.Size = new System.Drawing.Size(54, 18);
            this.lblShowAddress.TabIndex = 41;
            this.lblShowAddress.Text = "label43";
            // 
            // lblShowEmpID
            // 
            this.lblShowEmpID.AutoSize = true;
            this.lblShowEmpID.Location = new System.Drawing.Point(281, 122);
            this.lblShowEmpID.Name = "lblShowEmpID";
            this.lblShowEmpID.Size = new System.Drawing.Size(54, 18);
            this.lblShowEmpID.TabIndex = 40;
            this.lblShowEmpID.Text = "label42";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(146, 122);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(57, 18);
            this.label29.TabIndex = 39;
            this.label29.Text = "Emp ID";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(146, 221);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(80, 18);
            this.label30.TabIndex = 38;
            this.label30.Text = "Last Name";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(146, 270);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(41, 18);
            this.label31.TabIndex = 37;
            this.label31.Text = "DOB";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(595, 122);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(57, 18);
            this.label32.TabIndex = 36;
            this.label32.Text = "Gender";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(595, 221);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(86, 18);
            this.label33.TabIndex = 35;
            this.label33.Text = "Designation";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(595, 322);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(84, 18);
            this.label34.TabIndex = 34;
            this.label34.Text = "Contact No";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(146, 169);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(81, 18);
            this.label35.TabIndex = 33;
            this.label35.Text = "First Name";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(146, 322);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(39, 18);
            this.label36.TabIndex = 32;
            this.label36.Text = "DOJ";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(146, 371);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(49, 18);
            this.label37.TabIndex = 31;
            this.label37.Text = "Salary";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(595, 169);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(33, 18);
            this.label38.TabIndex = 30;
            this.label38.Text = "Age";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(595, 270);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(45, 18);
            this.label39.TabIndex = 29;
            this.label39.Text = "Email";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(595, 371);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(62, 18);
            this.label40.TabIndex = 28;
            this.label40.Text = "Address";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(377, 36);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(146, 24);
            this.label41.TabIndex = 27;
            this.label41.Text = "My Information";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.datagridBirthday);
            this.tabPage6.Controls.Add(this.label2);
            this.tabPage6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(972, 566);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Upcoming Birthday";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // datagridBirthday
            // 
            this.datagridBirthday.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridBirthday.Location = new System.Drawing.Point(15, 53);
            this.datagridBirthday.Name = "datagridBirthday";
            this.datagridBirthday.Size = new System.Drawing.Size(944, 498);
            this.datagridBirthday.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(399, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Upcoming Birthday";
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.groupBox1);
            this.tabPage11.Controls.Add(this.groupBox5);
            this.tabPage11.Controls.Add(this.groupBox2);
            this.tabPage11.Controls.Add(this.groupBox3);
            this.tabPage11.Controls.Add(this.groupBoxPassword);
            this.tabPage11.Location = new System.Drawing.Point(4, 25);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(972, 566);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "Settings";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label74);
            this.groupBox1.Controls.Add(this.radioButton17);
            this.groupBox1.Controls.Add(this.radioButton18);
            this.groupBox1.Controls.Add(this.radioButton16);
            this.groupBox1.Controls.Add(this.radioButton15);
            this.groupBox1.Controls.Add(this.radioButton14);
            this.groupBox1.Controls.Add(this.radioButton13);
            this.groupBox1.Controls.Add(this.radioButton12);
            this.groupBox1.Controls.Add(this.radioButton11);
            this.groupBox1.Controls.Add(this.radioButton10);
            this.groupBox1.Controls.Add(this.radioButton9);
            this.groupBox1.Controls.Add(this.radioButton8);
            this.groupBox1.Controls.Add(this.radioButton7);
            this.groupBox1.Controls.Add(this.radioButton25);
            this.groupBox1.Controls.Add(this.radioButton26);
            this.groupBox1.Controls.Add(this.radioButton27);
            this.groupBox1.Controls.Add(this.radioButton28);
            this.groupBox1.Controls.Add(this.radioButton29);
            this.groupBox1.Controls.Add(this.radioButton30);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(493, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(473, 261);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "3D & Beautiful Themes";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(6, 49);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(347, 16);
            this.label74.TabIndex = 19;
            this.label74.Text = "Select any one of the beautiful Theme for your application";
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton17.Location = new System.Drawing.Point(17, 219);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(86, 20);
            this.radioButton17.TabIndex = 18;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "Theme 16";
            this.radioButton17.UseVisualStyleBackColor = true;
            this.radioButton17.CheckedChanged += new System.EventHandler(this.radioButton17_CheckedChanged);
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton18.Location = new System.Drawing.Point(326, 191);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(86, 20);
            this.radioButton18.TabIndex = 17;
            this.radioButton18.TabStop = true;
            this.radioButton18.Text = "Theme 15";
            this.radioButton18.UseVisualStyleBackColor = true;
            this.radioButton18.CheckedChanged += new System.EventHandler(this.radioButton18_CheckedChanged);
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton16.Location = new System.Drawing.Point(326, 217);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(86, 20);
            this.radioButton16.TabIndex = 15;
            this.radioButton16.TabStop = true;
            this.radioButton16.Text = "Theme 18";
            this.radioButton16.UseVisualStyleBackColor = true;
            this.radioButton16.CheckedChanged += new System.EventHandler(this.radioButton16_CheckedChanged);
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton15.Location = new System.Drawing.Point(326, 165);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(86, 20);
            this.radioButton15.TabIndex = 14;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "Theme 14";
            this.radioButton15.UseVisualStyleBackColor = true;
            this.radioButton15.CheckedChanged += new System.EventHandler(this.radioButton15_CheckedChanged);
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton14.Location = new System.Drawing.Point(326, 139);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(86, 20);
            this.radioButton14.TabIndex = 13;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "Theme 13";
            this.radioButton14.UseVisualStyleBackColor = true;
            this.radioButton14.CheckedChanged += new System.EventHandler(this.radioButton14_CheckedChanged);
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton13.Location = new System.Drawing.Point(326, 113);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(86, 20);
            this.radioButton13.TabIndex = 12;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "Theme 12";
            this.radioButton13.UseVisualStyleBackColor = true;
            this.radioButton13.CheckedChanged += new System.EventHandler(this.radioButton13_CheckedChanged);
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton12.Location = new System.Drawing.Point(326, 87);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(86, 20);
            this.radioButton12.TabIndex = 11;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "Theme 11";
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton12_CheckedChanged);
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton11.Location = new System.Drawing.Point(166, 163);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(79, 20);
            this.radioButton11.TabIndex = 10;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "Theme 9";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton10.Location = new System.Drawing.Point(166, 189);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(86, 20);
            this.radioButton10.TabIndex = 9;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "Theme 10";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton10_CheckedChanged);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton9.Location = new System.Drawing.Point(166, 215);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(86, 20);
            this.radioButton9.TabIndex = 8;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "Theme 17";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton8.Location = new System.Drawing.Point(166, 137);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(79, 20);
            this.radioButton8.TabIndex = 7;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Theme 8";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton7.Location = new System.Drawing.Point(166, 111);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(79, 20);
            this.radioButton7.TabIndex = 6;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Theme 7";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.CheckedChanged += new System.EventHandler(this.radioButton7_CheckedChanged);
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton25.Location = new System.Drawing.Point(166, 85);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(79, 20);
            this.radioButton25.TabIndex = 5;
            this.radioButton25.TabStop = true;
            this.radioButton25.Text = "Theme 6";
            this.radioButton25.UseVisualStyleBackColor = true;
            this.radioButton25.CheckedChanged += new System.EventHandler(this.radioButton25_CheckedChanged);
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton26.Location = new System.Drawing.Point(17, 193);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(79, 20);
            this.radioButton26.TabIndex = 4;
            this.radioButton26.TabStop = true;
            this.radioButton26.Text = "Theme 5";
            this.radioButton26.UseVisualStyleBackColor = true;
            this.radioButton26.CheckedChanged += new System.EventHandler(this.radioButton26_CheckedChanged);
            // 
            // radioButton27
            // 
            this.radioButton27.AutoSize = true;
            this.radioButton27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton27.Location = new System.Drawing.Point(17, 165);
            this.radioButton27.Name = "radioButton27";
            this.radioButton27.Size = new System.Drawing.Size(79, 20);
            this.radioButton27.TabIndex = 3;
            this.radioButton27.TabStop = true;
            this.radioButton27.Text = "Theme 4";
            this.radioButton27.UseVisualStyleBackColor = true;
            this.radioButton27.CheckedChanged += new System.EventHandler(this.radioButton27_CheckedChanged);
            // 
            // radioButton28
            // 
            this.radioButton28.AutoSize = true;
            this.radioButton28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton28.Location = new System.Drawing.Point(17, 139);
            this.radioButton28.Name = "radioButton28";
            this.radioButton28.Size = new System.Drawing.Size(79, 20);
            this.radioButton28.TabIndex = 2;
            this.radioButton28.TabStop = true;
            this.radioButton28.Text = "Theme 3";
            this.radioButton28.UseVisualStyleBackColor = true;
            this.radioButton28.CheckedChanged += new System.EventHandler(this.radioButton28_CheckedChanged);
            // 
            // radioButton29
            // 
            this.radioButton29.AutoSize = true;
            this.radioButton29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton29.Location = new System.Drawing.Point(17, 113);
            this.radioButton29.Name = "radioButton29";
            this.radioButton29.Size = new System.Drawing.Size(79, 20);
            this.radioButton29.TabIndex = 1;
            this.radioButton29.TabStop = true;
            this.radioButton29.Text = "Theme 2";
            this.radioButton29.UseVisualStyleBackColor = true;
            this.radioButton29.CheckedChanged += new System.EventHandler(this.radioButton29_CheckedChanged);
            // 
            // radioButton30
            // 
            this.radioButton30.AutoSize = true;
            this.radioButton30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton30.Location = new System.Drawing.Point(17, 87);
            this.radioButton30.Name = "radioButton30";
            this.radioButton30.Size = new System.Drawing.Size(79, 20);
            this.radioButton30.TabIndex = 0;
            this.radioButton30.TabStop = true;
            this.radioButton30.Text = "Theme 1";
            this.radioButton30.UseVisualStyleBackColor = true;
            this.radioButton30.CheckedChanged += new System.EventHandler(this.radioButton30_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.groupBox8);
            this.groupBox5.Controls.Add(this.label80);
            this.groupBox5.Controls.Add(this.radioButton49);
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Controls.Add(this.radioButton50);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.radioButton51);
            this.groupBox5.Controls.Add(this.radioButton52);
            this.groupBox5.Controls.Add(this.radioButton53);
            this.groupBox5.Controls.Add(this.radioButton54);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(283, 30);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(200, 251);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Basic Themes";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label84);
            this.groupBox8.Controls.Add(this.radioButton73);
            this.groupBox8.Controls.Add(this.radioButton74);
            this.groupBox8.Controls.Add(this.radioButton75);
            this.groupBox8.Controls.Add(this.radioButton76);
            this.groupBox8.Controls.Add(this.radioButton77);
            this.groupBox8.Controls.Add(this.radioButton78);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(0, 0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(200, 251);
            this.groupBox8.TabIndex = 5;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Basic Themes";
            // 
            // label84
            // 
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(6, 39);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(188, 36);
            this.label84.TabIndex = 25;
            this.label84.Text = "Select any one of the beautiful Theme for your application";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // radioButton73
            // 
            this.radioButton73.AutoSize = true;
            this.radioButton73.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton73.Location = new System.Drawing.Point(6, 222);
            this.radioButton73.Name = "radioButton73";
            this.radioButton73.Size = new System.Drawing.Size(89, 20);
            this.radioButton73.TabIndex = 24;
            this.radioButton73.TabStop = true;
            this.radioButton73.Text = "Slate Grey";
            this.radioButton73.UseVisualStyleBackColor = true;
            this.radioButton73.CheckedChanged += new System.EventHandler(this.radioButton73_CheckedChanged);
            // 
            // radioButton74
            // 
            this.radioButton74.AutoSize = true;
            this.radioButton74.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton74.Location = new System.Drawing.Point(6, 196);
            this.radioButton74.Name = "radioButton74";
            this.radioButton74.Size = new System.Drawing.Size(65, 20);
            this.radioButton74.TabIndex = 23;
            this.radioButton74.TabStop = true;
            this.radioButton74.Text = "Salom";
            this.radioButton74.UseVisualStyleBackColor = true;
            this.radioButton74.CheckedChanged += new System.EventHandler(this.radioButton74_CheckedChanged);
            // 
            // radioButton75
            // 
            this.radioButton75.AutoSize = true;
            this.radioButton75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton75.Location = new System.Drawing.Point(6, 168);
            this.radioButton75.Name = "radioButton75";
            this.radioButton75.Size = new System.Drawing.Size(64, 20);
            this.radioButton75.TabIndex = 22;
            this.radioButton75.TabStop = true;
            this.radioButton75.Text = "Vinitini";
            this.radioButton75.UseVisualStyleBackColor = true;
            this.radioButton75.CheckedChanged += new System.EventHandler(this.radioButton75_CheckedChanged);
            // 
            // radioButton76
            // 
            this.radioButton76.AutoSize = true;
            this.radioButton76.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton76.Location = new System.Drawing.Point(6, 142);
            this.radioButton76.Name = "radioButton76";
            this.radioButton76.Size = new System.Drawing.Size(100, 20);
            this.radioButton76.TabIndex = 21;
            this.radioButton76.TabStop = true;
            this.radioButton76.Text = "Night Riders";
            this.radioButton76.UseVisualStyleBackColor = true;
            this.radioButton76.CheckedChanged += new System.EventHandler(this.radioButton76_CheckedChanged);
            // 
            // radioButton77
            // 
            this.radioButton77.AutoSize = true;
            this.radioButton77.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton77.Location = new System.Drawing.Point(6, 116);
            this.radioButton77.Name = "radioButton77";
            this.radioButton77.Size = new System.Drawing.Size(175, 20);
            this.radioButton77.TabIndex = 20;
            this.radioButton77.TabStop = true;
            this.radioButton77.Text = "Harley Davidson Orange";
            this.radioButton77.UseVisualStyleBackColor = true;
            this.radioButton77.CheckedChanged += new System.EventHandler(this.radioButton77_CheckedChanged);
            // 
            // radioButton78
            // 
            this.radioButton78.AutoSize = true;
            this.radioButton78.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton78.Location = new System.Drawing.Point(6, 90);
            this.radioButton78.Name = "radioButton78";
            this.radioButton78.Size = new System.Drawing.Size(93, 20);
            this.radioButton78.TabIndex = 19;
            this.radioButton78.TabStop = true;
            this.radioButton78.Text = "Half Baked";
            this.radioButton78.UseVisualStyleBackColor = true;
            this.radioButton78.CheckedChanged += new System.EventHandler(this.radioButton78_CheckedChanged);
            // 
            // label80
            // 
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(6, 39);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(188, 36);
            this.label80.TabIndex = 25;
            this.label80.Text = "Select any one of the beautiful Theme for your application";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // radioButton49
            // 
            this.radioButton49.AutoSize = true;
            this.radioButton49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton49.Location = new System.Drawing.Point(6, 222);
            this.radioButton49.Name = "radioButton49";
            this.radioButton49.Size = new System.Drawing.Size(89, 20);
            this.radioButton49.TabIndex = 24;
            this.radioButton49.TabStop = true;
            this.radioButton49.Text = "Slate Grey";
            this.radioButton49.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label83);
            this.groupBox7.Controls.Add(this.radioButton55);
            this.groupBox7.Controls.Add(this.radioButton56);
            this.groupBox7.Controls.Add(this.radioButton57);
            this.groupBox7.Controls.Add(this.radioButton58);
            this.groupBox7.Controls.Add(this.radioButton59);
            this.groupBox7.Controls.Add(this.radioButton60);
            this.groupBox7.Controls.Add(this.radioButton61);
            this.groupBox7.Controls.Add(this.radioButton62);
            this.groupBox7.Controls.Add(this.radioButton63);
            this.groupBox7.Controls.Add(this.radioButton64);
            this.groupBox7.Controls.Add(this.radioButton65);
            this.groupBox7.Controls.Add(this.radioButton66);
            this.groupBox7.Controls.Add(this.radioButton67);
            this.groupBox7.Controls.Add(this.radioButton68);
            this.groupBox7.Controls.Add(this.radioButton69);
            this.groupBox7.Controls.Add(this.radioButton70);
            this.groupBox7.Controls.Add(this.radioButton71);
            this.groupBox7.Controls.Add(this.radioButton72);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(206, 0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(473, 261);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "3D & Beautiful Themes";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(6, 49);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(347, 16);
            this.label83.TabIndex = 19;
            this.label83.Text = "Select any one of the beautiful Theme for your application";
            // 
            // radioButton55
            // 
            this.radioButton55.AutoSize = true;
            this.radioButton55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton55.Location = new System.Drawing.Point(17, 219);
            this.radioButton55.Name = "radioButton55";
            this.radioButton55.Size = new System.Drawing.Size(108, 20);
            this.radioButton55.TabIndex = 18;
            this.radioButton55.TabStop = true;
            this.radioButton55.Text = "radioButton17";
            this.radioButton55.UseVisualStyleBackColor = true;
            // 
            // radioButton56
            // 
            this.radioButton56.AutoSize = true;
            this.radioButton56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton56.Location = new System.Drawing.Point(326, 191);
            this.radioButton56.Name = "radioButton56";
            this.radioButton56.Size = new System.Drawing.Size(108, 20);
            this.radioButton56.TabIndex = 17;
            this.radioButton56.TabStop = true;
            this.radioButton56.Text = "radioButton18";
            this.radioButton56.UseVisualStyleBackColor = true;
            // 
            // radioButton57
            // 
            this.radioButton57.AutoSize = true;
            this.radioButton57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton57.Location = new System.Drawing.Point(326, 217);
            this.radioButton57.Name = "radioButton57";
            this.radioButton57.Size = new System.Drawing.Size(108, 20);
            this.radioButton57.TabIndex = 15;
            this.radioButton57.TabStop = true;
            this.radioButton57.Text = "radioButton16";
            this.radioButton57.UseVisualStyleBackColor = true;
            // 
            // radioButton58
            // 
            this.radioButton58.AutoSize = true;
            this.radioButton58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton58.Location = new System.Drawing.Point(326, 165);
            this.radioButton58.Name = "radioButton58";
            this.radioButton58.Size = new System.Drawing.Size(108, 20);
            this.radioButton58.TabIndex = 14;
            this.radioButton58.TabStop = true;
            this.radioButton58.Text = "radioButton15";
            this.radioButton58.UseVisualStyleBackColor = true;
            // 
            // radioButton59
            // 
            this.radioButton59.AutoSize = true;
            this.radioButton59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton59.Location = new System.Drawing.Point(326, 139);
            this.radioButton59.Name = "radioButton59";
            this.radioButton59.Size = new System.Drawing.Size(108, 20);
            this.radioButton59.TabIndex = 13;
            this.radioButton59.TabStop = true;
            this.radioButton59.Text = "radioButton14";
            this.radioButton59.UseVisualStyleBackColor = true;
            // 
            // radioButton60
            // 
            this.radioButton60.AutoSize = true;
            this.radioButton60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton60.Location = new System.Drawing.Point(326, 113);
            this.radioButton60.Name = "radioButton60";
            this.radioButton60.Size = new System.Drawing.Size(108, 20);
            this.radioButton60.TabIndex = 12;
            this.radioButton60.TabStop = true;
            this.radioButton60.Text = "radioButton13";
            this.radioButton60.UseVisualStyleBackColor = true;
            // 
            // radioButton61
            // 
            this.radioButton61.AutoSize = true;
            this.radioButton61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton61.Location = new System.Drawing.Point(326, 87);
            this.radioButton61.Name = "radioButton61";
            this.radioButton61.Size = new System.Drawing.Size(108, 20);
            this.radioButton61.TabIndex = 11;
            this.radioButton61.TabStop = true;
            this.radioButton61.Text = "radioButton12";
            this.radioButton61.UseVisualStyleBackColor = true;
            // 
            // radioButton62
            // 
            this.radioButton62.AutoSize = true;
            this.radioButton62.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton62.Location = new System.Drawing.Point(166, 163);
            this.radioButton62.Name = "radioButton62";
            this.radioButton62.Size = new System.Drawing.Size(108, 20);
            this.radioButton62.TabIndex = 10;
            this.radioButton62.TabStop = true;
            this.radioButton62.Text = "radioButton11";
            this.radioButton62.UseVisualStyleBackColor = true;
            // 
            // radioButton63
            // 
            this.radioButton63.AutoSize = true;
            this.radioButton63.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton63.Location = new System.Drawing.Point(166, 189);
            this.radioButton63.Name = "radioButton63";
            this.radioButton63.Size = new System.Drawing.Size(108, 20);
            this.radioButton63.TabIndex = 9;
            this.radioButton63.TabStop = true;
            this.radioButton63.Text = "radioButton10";
            this.radioButton63.UseVisualStyleBackColor = true;
            // 
            // radioButton64
            // 
            this.radioButton64.AutoSize = true;
            this.radioButton64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton64.Location = new System.Drawing.Point(166, 215);
            this.radioButton64.Name = "radioButton64";
            this.radioButton64.Size = new System.Drawing.Size(101, 20);
            this.radioButton64.TabIndex = 8;
            this.radioButton64.TabStop = true;
            this.radioButton64.Text = "radioButton9";
            this.radioButton64.UseVisualStyleBackColor = true;
            // 
            // radioButton65
            // 
            this.radioButton65.AutoSize = true;
            this.radioButton65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton65.Location = new System.Drawing.Point(166, 137);
            this.radioButton65.Name = "radioButton65";
            this.radioButton65.Size = new System.Drawing.Size(101, 20);
            this.radioButton65.TabIndex = 7;
            this.radioButton65.TabStop = true;
            this.radioButton65.Text = "radioButton8";
            this.radioButton65.UseVisualStyleBackColor = true;
            // 
            // radioButton66
            // 
            this.radioButton66.AutoSize = true;
            this.radioButton66.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton66.Location = new System.Drawing.Point(166, 111);
            this.radioButton66.Name = "radioButton66";
            this.radioButton66.Size = new System.Drawing.Size(101, 20);
            this.radioButton66.TabIndex = 6;
            this.radioButton66.TabStop = true;
            this.radioButton66.Text = "radioButton7";
            this.radioButton66.UseVisualStyleBackColor = true;
            // 
            // radioButton67
            // 
            this.radioButton67.AutoSize = true;
            this.radioButton67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton67.Location = new System.Drawing.Point(166, 85);
            this.radioButton67.Name = "radioButton67";
            this.radioButton67.Size = new System.Drawing.Size(108, 20);
            this.radioButton67.TabIndex = 5;
            this.radioButton67.TabStop = true;
            this.radioButton67.Text = "radioButton25";
            this.radioButton67.UseVisualStyleBackColor = true;
            // 
            // radioButton68
            // 
            this.radioButton68.AutoSize = true;
            this.radioButton68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton68.Location = new System.Drawing.Point(17, 193);
            this.radioButton68.Name = "radioButton68";
            this.radioButton68.Size = new System.Drawing.Size(108, 20);
            this.radioButton68.TabIndex = 4;
            this.radioButton68.TabStop = true;
            this.radioButton68.Text = "radioButton26";
            this.radioButton68.UseVisualStyleBackColor = true;
            // 
            // radioButton69
            // 
            this.radioButton69.AutoSize = true;
            this.radioButton69.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton69.Location = new System.Drawing.Point(17, 165);
            this.radioButton69.Name = "radioButton69";
            this.radioButton69.Size = new System.Drawing.Size(108, 20);
            this.radioButton69.TabIndex = 3;
            this.radioButton69.TabStop = true;
            this.radioButton69.Text = "radioButton27";
            this.radioButton69.UseVisualStyleBackColor = true;
            // 
            // radioButton70
            // 
            this.radioButton70.AutoSize = true;
            this.radioButton70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton70.Location = new System.Drawing.Point(17, 139);
            this.radioButton70.Name = "radioButton70";
            this.radioButton70.Size = new System.Drawing.Size(108, 20);
            this.radioButton70.TabIndex = 2;
            this.radioButton70.TabStop = true;
            this.radioButton70.Text = "radioButton28";
            this.radioButton70.UseVisualStyleBackColor = true;
            // 
            // radioButton71
            // 
            this.radioButton71.AutoSize = true;
            this.radioButton71.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton71.Location = new System.Drawing.Point(17, 113);
            this.radioButton71.Name = "radioButton71";
            this.radioButton71.Size = new System.Drawing.Size(108, 20);
            this.radioButton71.TabIndex = 1;
            this.radioButton71.TabStop = true;
            this.radioButton71.Text = "radioButton29";
            this.radioButton71.UseVisualStyleBackColor = true;
            // 
            // radioButton72
            // 
            this.radioButton72.AutoSize = true;
            this.radioButton72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton72.Location = new System.Drawing.Point(17, 87);
            this.radioButton72.Name = "radioButton72";
            this.radioButton72.Size = new System.Drawing.Size(108, 20);
            this.radioButton72.TabIndex = 0;
            this.radioButton72.TabStop = true;
            this.radioButton72.Text = "radioButton30";
            this.radioButton72.UseVisualStyleBackColor = true;
            // 
            // radioButton50
            // 
            this.radioButton50.AutoSize = true;
            this.radioButton50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton50.Location = new System.Drawing.Point(6, 196);
            this.radioButton50.Name = "radioButton50";
            this.radioButton50.Size = new System.Drawing.Size(65, 20);
            this.radioButton50.TabIndex = 23;
            this.radioButton50.TabStop = true;
            this.radioButton50.Text = "Salom";
            this.radioButton50.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.linkLabel3);
            this.groupBox6.Controls.Add(this.label81);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(-285, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(218, 110);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Password";
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel3.Location = new System.Drawing.Point(6, 77);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(139, 16);
            this.linkLabel3.TabIndex = 1;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "Change My Password";
            // 
            // label81
            // 
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(6, 30);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(191, 38);
            this.label81.TabIndex = 0;
            this.label81.Text = "To change your password Kindly use your old password .";
            // 
            // radioButton51
            // 
            this.radioButton51.AutoSize = true;
            this.radioButton51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton51.Location = new System.Drawing.Point(6, 168);
            this.radioButton51.Name = "radioButton51";
            this.radioButton51.Size = new System.Drawing.Size(64, 20);
            this.radioButton51.TabIndex = 22;
            this.radioButton51.TabStop = true;
            this.radioButton51.Text = "Vinitini";
            this.radioButton51.UseVisualStyleBackColor = true;
            // 
            // radioButton52
            // 
            this.radioButton52.AutoSize = true;
            this.radioButton52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton52.Location = new System.Drawing.Point(6, 142);
            this.radioButton52.Name = "radioButton52";
            this.radioButton52.Size = new System.Drawing.Size(100, 20);
            this.radioButton52.TabIndex = 21;
            this.radioButton52.TabStop = true;
            this.radioButton52.Text = "Night Riders";
            this.radioButton52.UseVisualStyleBackColor = true;
            // 
            // radioButton53
            // 
            this.radioButton53.AutoSize = true;
            this.radioButton53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton53.Location = new System.Drawing.Point(6, 116);
            this.radioButton53.Name = "radioButton53";
            this.radioButton53.Size = new System.Drawing.Size(175, 20);
            this.radioButton53.TabIndex = 20;
            this.radioButton53.TabStop = true;
            this.radioButton53.Text = "Harley Davidson Orange";
            this.radioButton53.UseVisualStyleBackColor = true;
            // 
            // radioButton54
            // 
            this.radioButton54.AutoSize = true;
            this.radioButton54.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton54.Location = new System.Drawing.Point(6, 90);
            this.radioButton54.Name = "radioButton54";
            this.radioButton54.Size = new System.Drawing.Size(93, 20);
            this.radioButton54.TabIndex = 19;
            this.radioButton54.TabStop = true;
            this.radioButton54.Text = "Half Baked";
            this.radioButton54.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label72);
            this.groupBox2.Controls.Add(this.radioButton19);
            this.groupBox2.Controls.Add(this.radioButton20);
            this.groupBox2.Controls.Add(this.radioButton21);
            this.groupBox2.Controls.Add(this.radioButton22);
            this.groupBox2.Controls.Add(this.radioButton23);
            this.groupBox2.Controls.Add(this.radioButton24);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(283, 30);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 251);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Basic Themes";
            // 
            // label72
            // 
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(6, 39);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(188, 36);
            this.label72.TabIndex = 25;
            this.label72.Text = "Select any one of the beautiful Theme for your application";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton19.Location = new System.Drawing.Point(6, 222);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(89, 20);
            this.radioButton19.TabIndex = 24;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "Slate Grey";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton20.Location = new System.Drawing.Point(6, 196);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(65, 20);
            this.radioButton20.TabIndex = 23;
            this.radioButton20.TabStop = true;
            this.radioButton20.Text = "Salom";
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton21.Location = new System.Drawing.Point(6, 168);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(64, 20);
            this.radioButton21.TabIndex = 22;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "Vinitini";
            this.radioButton21.UseVisualStyleBackColor = true;
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton22.Location = new System.Drawing.Point(6, 142);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(100, 20);
            this.radioButton22.TabIndex = 21;
            this.radioButton22.TabStop = true;
            this.radioButton22.Text = "Night Riders";
            this.radioButton22.UseVisualStyleBackColor = true;
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton23.Location = new System.Drawing.Point(6, 116);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(175, 20);
            this.radioButton23.TabIndex = 20;
            this.radioButton23.TabStop = true;
            this.radioButton23.Text = "Harley Davidson Orange";
            this.radioButton23.UseVisualStyleBackColor = true;
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton24.Location = new System.Drawing.Point(6, 90);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(93, 20);
            this.radioButton24.TabIndex = 19;
            this.radioButton24.TabStop = true;
            this.radioButton24.Text = "Half Baked";
            this.radioButton24.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.linkLabel2);
            this.groupBox3.Controls.Add(this.label76);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(6, 30);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(218, 110);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Password";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.Location = new System.Drawing.Point(6, 77);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(139, 16);
            this.linkLabel2.TabIndex = 1;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Change My Password";
            // 
            // label76
            // 
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(6, 30);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(191, 38);
            this.label76.TabIndex = 0;
            this.label76.Text = "To change your password Kindly use your old password .";
            // 
            // groupBoxPassword
            // 
            this.groupBoxPassword.Controls.Add(this.linkLabel1);
            this.groupBoxPassword.Controls.Add(this.label75);
            this.groupBoxPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxPassword.Location = new System.Drawing.Point(6, 30);
            this.groupBoxPassword.Name = "groupBoxPassword";
            this.groupBoxPassword.Size = new System.Drawing.Size(218, 110);
            this.groupBoxPassword.TabIndex = 3;
            this.groupBoxPassword.TabStop = false;
            this.groupBoxPassword.Text = "Password";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(6, 77);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(139, 16);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Change My Password";
            // 
            // label75
            // 
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(6, 30);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(191, 38);
            this.label75.TabIndex = 0;
            this.label75.Text = "To change your password Kindly use your old password .";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(56)))));
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnExit.Location = new System.Drawing.Point(892, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 36);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(56)))));
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnLogout.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnLogout.Location = new System.Drawing.Point(786, 12);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(100, 36);
            this.btnLogout.TabIndex = 3;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.button4_Click);
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.ForeColor = System.Drawing.Color.White;
            this.label85.Location = new System.Drawing.Point(128, 66);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(109, 20);
            this.label85.TabIndex = 33;
            this.label85.Text = "[Name Here]";
            this.label85.Visible = false;
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.White;
            this.lblWelcome.Location = new System.Drawing.Point(26, 66);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(82, 20);
            this.lblWelcome.TabIndex = 32;
            this.lblWelcome.Text = "Welcome";
            // 
            // HRPortalPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(188)))), ((int)(((byte)(171)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1004, 726);
            this.Controls.Add(this.label85);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HRPortalPage";
            this.Text = "HR Portal";
            this.Load += new System.EventHandler(this.HRPortalPage_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datagridShowData)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datagridLeaves)).EndInit();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridBirthday)).EndInit();
            this.tabPage11.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBoxPassword.ResumeLayout(false);
            this.groupBoxPassword.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView datagridShowData;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnApprovedLeave;
        private System.Windows.Forms.Button btnPendingLEave;
        private System.Windows.Forms.DataGridView datagridLeaves;
        private System.Windows.Forms.DataGridView datagridBirthday;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAcceptLeave;
        private System.Windows.Forms.Button btnDeclineLeave;
        private System.Windows.Forms.Button btnAddEmp;
        private System.Windows.Forms.RadioButton radioOther;
        private System.Windows.Forms.RadioButton radioFemale;
        private System.Windows.Forms.RadioButton radioMale;
        private System.Windows.Forms.TextBox txtDOJ;
        private System.Windows.Forms.TextBox txtDOB;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtContactNo;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtDesignation;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtSkill;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label lblShowFirstName;
        private System.Windows.Forms.Label lblShowSalary;
        private System.Windows.Forms.Label lblShowGender;
        private System.Windows.Forms.Label lblShowDesignation;
        private System.Windows.Forms.Label lblShowDOJ;
        private System.Windows.Forms.Label lblShowEmail;
        private System.Windows.Forms.Label lblShowLastName;
        private System.Windows.Forms.Label lblShowDOB;
        private System.Windows.Forms.Label lblShowAge;
        private System.Windows.Forms.Label lblShowContactNo;
        private System.Windows.Forms.Label lblShowAddress;
        private System.Windows.Forms.Label lblShowEmpID;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txtxSearchByEmpID;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblDesignation;
        private System.Windows.Forms.Label lblDOJ;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblContactNo;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblSkill;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.RadioButton radioButton73;
        private System.Windows.Forms.RadioButton radioButton74;
        private System.Windows.Forms.RadioButton radioButton75;
        private System.Windows.Forms.RadioButton radioButton76;
        private System.Windows.Forms.RadioButton radioButton77;
        private System.Windows.Forms.RadioButton radioButton78;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.RadioButton radioButton49;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.RadioButton radioButton55;
        private System.Windows.Forms.RadioButton radioButton56;
        private System.Windows.Forms.RadioButton radioButton57;
        private System.Windows.Forms.RadioButton radioButton58;
        private System.Windows.Forms.RadioButton radioButton59;
        private System.Windows.Forms.RadioButton radioButton60;
        private System.Windows.Forms.RadioButton radioButton61;
        private System.Windows.Forms.RadioButton radioButton62;
        private System.Windows.Forms.RadioButton radioButton63;
        private System.Windows.Forms.RadioButton radioButton64;
        private System.Windows.Forms.RadioButton radioButton65;
        private System.Windows.Forms.RadioButton radioButton66;
        private System.Windows.Forms.RadioButton radioButton67;
        private System.Windows.Forms.RadioButton radioButton68;
        private System.Windows.Forms.RadioButton radioButton69;
        private System.Windows.Forms.RadioButton radioButton70;
        private System.Windows.Forms.RadioButton radioButton71;
        private System.Windows.Forms.RadioButton radioButton72;
        private System.Windows.Forms.RadioButton radioButton50;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.RadioButton radioButton51;
        private System.Windows.Forms.RadioButton radioButton52;
        private System.Windows.Forms.RadioButton radioButton53;
        private System.Windows.Forms.RadioButton radioButton54;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.GroupBox groupBoxPassword;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.RadioButton radioButton27;
        private System.Windows.Forms.RadioButton radioButton28;
        private System.Windows.Forms.RadioButton radioButton29;
        private System.Windows.Forms.RadioButton radioButton30;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtDeptId;
        private System.Windows.Forms.Label lblDeptId;
        private System.Windows.Forms.Label label44;


    }
}