﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Management_System
{
    public partial class ManagerHomePage : Form
    {
        public ManagerHomePage()
        {
            InitializeComponent();
        }

        private void btnAllocateMembers_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }


        //
        //
        //
        //Themes
        //
        //
        //

        private void Theme1()
        {

            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }

        private void Theme2()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme3()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme4()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._4;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme5()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._5;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme6()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._6;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme7()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._7;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme8()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._8;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme9()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._9;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme10()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._10;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme11()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._11;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme12()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._12;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme13()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._13;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme14()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._14;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme15()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._15;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme16()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._16;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme17()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._16;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }
        private void Theme18()
        {
            this.BackgroundImage = global::Employee_Management_System.Properties.Resources._15;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }

        private void BasicTheme1()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(140)))), ((int)(((byte)(137)))));
        }
        private void BasicTheme2()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
        }
        private void BasicTheme3()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(43)))), ((int)(((byte)(43)))));
        }
        private void BasicTheme4()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(171)))), ((int)(((byte)(88)))));
        }
        private void BasicTheme5()
        {
            this.BackColor = System.Drawing.Color.Salmon;
        }
        private void BasicTheme6()
        {
            this.BackColor = System.Drawing.Color.SlateGray;
        }




      /// <summary>
      /// End Of Themes
      /// </summary>
      /// <param name="sender"></param>
      /// <param name="e"></param>












        private void label32_Click(object sender, EventArgs e)
        {
            
        }

        private void tabPageSetting_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ChangePassword frmChangePassword = new ChangePassword();
            frmChangePassword.Show();
        }


      

       
        private void btnApplyTheme_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Theme1();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Theme2();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Theme3();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Theme4();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            Theme5();
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            Theme6();
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            Theme7();
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            Theme8();
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            Theme11();
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            Theme10();
        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
            Theme12();
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            Theme13();
        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            Theme14();
        }

        private void radioButton15_Click(object sender, EventArgs e)
        {

        }

        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            Theme15();
        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
            Theme18();
        }

        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {
            Theme17();
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            Theme9();
        }

        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {
            Theme16();
        }

        private void radioButton24_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme1();
        }

        private void radioButton23_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme2();
        }

        private void radioButton22_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme4();
        }

        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme5();
        }

        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme6();
        }

        private void radioButton21_CheckedChanged(object sender, EventArgs e)
        {
            BasicTheme3();
        }

        private void ManagerHomePage_Load(object sender, EventArgs e)
        {

        }



    }
}
