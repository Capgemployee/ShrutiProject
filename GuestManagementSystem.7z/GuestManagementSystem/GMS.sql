CREATE TABLE Guest_121824
(
	GuestID int PRIMARY KEY,
	GuestName varchar(30),
	ContactNo bigint
)


CREATE PROCEDURE AddGuest_121824
(
	@GuestID int,
	@GuestName varchar(30),
	@ContactNo bigint
)
AS
INSERT INTO Guest_121824
VALUES(@GuestID,@GuestName,@ContactNo)

EXEC AddGuest_121824 1002,'Ajinkya Rahane',9988775985


CREATE PROCEDURE GetAllGuests_121824
AS
SELECT * FROM Guest_121824

EXEC GetAllGuests_121824

CREATE PROCEDURE RetrieveGuestInfo_121824
(
	@GuestID int
)
AS
SELECT * FROM Guest_121824
WHERE GuestID=@GuestID



CREATE PROCEDURE DeleteGuestInfo_121824
(
	@GuestID int
)
AS
DELETE FROM Guest_121824
WHERE GuestID=@GuestID




CREATE PROCEDURE UpdateGuestInfo_121824
(
	@GuestID int,
	@GuestName varchar(30),
	@ContactNo bigint
)
AS
UPDATE Guest_121824 SET GuestName=@GuestName,ContactNo=@ContactNo
WHERE GuestID=@GuestID


